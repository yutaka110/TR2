#include "EffectSystem.h"

#include <algorithm>
#include <string>
#include <utility>

void EffectSystem::RegisterAsset(EffectAsset asset) {
    if (asset.name.empty()) {
        return;
    }
    EnsureDefaultComponent(asset);
    const std::string assetName = asset.name;
    assets_[assetName] = std::move(asset);

    for (EffectInstance& instance : instances_) {
        if (instance.assetName == assetName) {
            instance.asset = FindAsset(assetName);
        }
    }
}

const EffectAsset* EffectSystem::FindAsset(std::string_view name) const {
    const auto found = assets_.find(std::string(name));
    if (found == assets_.end()) {
        return nullptr;
    }
    return &found->second;
}

uint32_t EffectSystem::PlayEffect(std::string_view name, const Vector3& position) {
    return PlayEffectWithParams(
        name,
        position,
        {1.0f, 1.0f, 1.0f, 1.0f},
        {1.0f, 1.0f, 1.0f});
}

uint32_t EffectSystem::PlayEffectWithParams(
    std::string_view name,
    const Vector3& position,
    const Vector4& color,
    const Vector3& scale) {
    const EffectAsset* asset = FindAsset(name);
    if (asset == nullptr) {
        return 0;
    }

    EffectInstance instance{};
    instance.id = nextInstanceId_++;
    instance.assetName = asset->name;
    instance.asset = asset;
    instance.components.reserve(asset->components.size());
    for (const EffectComponentAsset& component : asset->components) {
        instance.components.push_back({component.id, 0.0f, true});
    }
    instance.transform.translate = position;
    instance.transform.rotate = {0.0f, 0.0f, 0.0f};
    instance.transform.scale = {
        asset->size.x * scale.x,
        asset->size.y * scale.y,
        asset->size.z * scale.z,
    };
    instance.color = {
        asset->color.x * color.x,
        asset->color.y * color.y,
        asset->color.z * color.z,
        asset->color.w * color.w,
    };
    instances_.push_back(instance);
    return instance.id;
}

void EffectSystem::StopEffect(uint32_t id) {
    instances_.erase(
        std::remove_if(
            instances_.begin(),
            instances_.end(),
            [id](const EffectInstance& instance) {
                return instance.id == id;
            }),
        instances_.end());
}

void EffectSystem::Update(float deltaTime) {
    for (EffectInstance& instance : instances_) {
        instance.age += deltaTime;
        for (EffectComponentInstance& component : instance.components) {
            component.age += deltaTime;
        }
    }

    instances_.erase(
        std::remove_if(
            instances_.begin(),
            instances_.end(),
            [](const EffectInstance& instance) {
                float totalLifetime = instance.asset != nullptr ? instance.asset->lifetime : 0.0f;
                if (instance.asset != nullptr) {
                    for (const EffectComponentAsset& component : instance.asset->components) {
                        const float componentEnd = component.startTime + component.duration;
                        if (componentEnd > totalLifetime) {
                            totalLifetime = componentEnd;
                        }
                    }
                }
                return instance.asset == nullptr ||
                       (totalLifetime > 0.0f && instance.age >= totalLifetime);
            }),
        instances_.end());
}

void EffectSystem::ClearInstances() {
    instances_.clear();
}

EffectInstance* EffectSystem::FindInstance(uint32_t id) {
    for (EffectInstance& instance : instances_) {
        if (instance.id == id) {
            return &instance;
        }
    }
    return nullptr;
}

void EffectSystem::RestartInstance(uint32_t id) {
    EffectInstance* instance = FindInstance(id);
    if (instance != nullptr) {
        instance->age = 0.0f;
        for (EffectComponentInstance& component : instance->components) {
            component.age = 0.0f;
            component.active = true;
        }
    }
}

std::vector<EffectRenderItem> EffectSystem::BuildRenderQueue(EffectLayer layer) const {
    std::vector<EffectRenderItem> queue;
    for (const EffectInstance& instance : instances_) {
        if (instance.asset == nullptr) {
            continue;
        }

        for (const EffectComponentInstance& componentInstance : instance.components) {
            if (!componentInstance.active) {
                continue;
            }

            const EffectComponentAsset* component =
                FindComponent(*instance.asset, componentInstance.componentId);
            if (component == nullptr || component->layer != layer) {
                continue;
            }

            const float localAge = instance.age - component->startTime;
            if (localAge < 0.0f ||
                (component->duration > 0.0f && localAge >= component->duration)) {
                continue;
            }

            float normalizedAge = 0.0f;
            if (component->duration > 0.0f) {
                normalizedAge = localAge / component->duration;
                if (normalizedAge > 1.0f) {
                    normalizedAge = 1.0f;
                }
            }

            queue.push_back({
                instance.asset,
                component,
                &instance,
                &componentInstance,
                component->type,
                component->passState.renderQueue,
                normalizedAge
            });
        }
    }

    std::sort(
        queue.begin(),
        queue.end(),
        [](const EffectRenderItem& left, const EffectRenderItem& right) {
            if (left.renderQueue != right.renderQueue) {
                return left.renderQueue < right.renderQueue;
            }
            const uint32_t leftId = left.instance != nullptr ? left.instance->id : 0;
            const uint32_t rightId = right.instance != nullptr ? right.instance->id : 0;
            return leftId < rightId;
        });
    return queue;
}

std::vector<EffectRenderItem> EffectSystem::BuildRenderQueue(EffectComponentType type) const {
    std::vector<EffectRenderItem> queue;
    for (const EffectInstance& instance : instances_) {
        if (instance.asset == nullptr) {
            continue;
        }

        for (const EffectComponentInstance& componentInstance : instance.components) {
            if (!componentInstance.active) {
                continue;
            }

            const EffectComponentAsset* component =
                FindComponent(*instance.asset, componentInstance.componentId);
            if (component == nullptr || component->type != type) {
                continue;
            }

            const float localAge = instance.age - component->startTime;
            if (localAge < 0.0f ||
                (component->duration > 0.0f && localAge >= component->duration)) {
                continue;
            }

            float normalizedAge = 0.0f;
            if (component->duration > 0.0f) {
                normalizedAge = localAge / component->duration;
                if (normalizedAge > 1.0f) {
                    normalizedAge = 1.0f;
                }
            }

            queue.push_back({
                instance.asset,
                component,
                &instance,
                &componentInstance,
                type,
                component->passState.renderQueue,
                normalizedAge
            });
        }
    }

    std::sort(
        queue.begin(),
        queue.end(),
        [](const EffectRenderItem& left, const EffectRenderItem& right) {
            if (left.renderQueue != right.renderQueue) {
                return left.renderQueue < right.renderQueue;
            }
            const uint32_t leftId = left.instance != nullptr ? left.instance->id : 0;
            const uint32_t rightId = right.instance != nullptr ? right.instance->id : 0;
            return leftId < rightId;
        });
    return queue;
}

const EffectAsset* EffectSystem::FindPrimaryAsset(EffectLayer layer) const {
    const std::vector<EffectRenderItem> queue = BuildRenderQueue(layer);
    if (!queue.empty()) {
        return queue.front().asset;
    }

    const EffectAsset* selected = nullptr;
    for (const auto& [name, asset] : assets_) {
        (void)name;
        if (asset.layer != layer) {
            continue;
        }
        if (selected == nullptr ||
            asset.passState.renderQueue < selected->passState.renderQueue ||
            (asset.passState.renderQueue == selected->passState.renderQueue &&
                asset.name < selected->name)) {
            selected = &asset;
        }
    }
    return selected;
}

const EffectComponentAsset* EffectSystem::FindPrimaryComponent(EffectComponentType type) const {
    const std::vector<EffectRenderItem> queue = BuildRenderQueue(type);
    if (!queue.empty()) {
        return queue.front().component;
    }

    const EffectComponentAsset* selected = nullptr;
    for (const auto& [assetName, asset] : assets_) {
        (void)assetName;
        for (const EffectComponentAsset& component : asset.components) {
            if (component.type != type) {
                continue;
            }
            if (selected == nullptr ||
                component.passState.renderQueue < selected->passState.renderQueue ||
                (component.passState.renderQueue == selected->passState.renderQueue &&
                    component.name < selected->name)) {
                selected = &component;
            }
        }
    }
    return selected;
}

void EffectSystem::EnsureDefaultComponent(EffectAsset& asset) {
    if (!asset.components.empty()) {
        for (uint32_t index = 0; index < asset.components.size(); ++index) {
            EffectComponentAsset& component = asset.components[index];
            if (component.id == 0) {
                component.id = index + 1;
            }
            if (component.name.empty()) {
                component.name = asset.name + "_component_" + std::to_string(component.id);
            }
            if (component.duration <= 0.0f) {
                component.duration = asset.lifetime;
            }
        }
        return;
    }

    EffectComponentAsset component{};
    component.id = 1;
    component.type = EffectComponentType::Particle;
    component.name = asset.name + "_particle";
    component.shader = asset.shader;
    component.texture = asset.texture;
    component.passState = asset.passState;
    component.layer = asset.layer;
    component.startTime = 0.0f;
    component.duration = asset.lifetime;
    component.emissive = asset.emissive;
    component.distortionStrength = asset.distortionStrength;
    component.noiseStrength = asset.noiseStrength;
    component.uvScrollSpeed = asset.uvScrollSpeed;
    component.pulseSpeed = asset.pulseSpeed;
    component.spawnRadius = asset.spawnRadius;
    component.color = asset.color;
    component.size = asset.size;
    asset.components.push_back(std::move(component));
}

const EffectComponentAsset* EffectSystem::FindComponent(
    const EffectAsset& asset,
    uint32_t componentId) {
    for (const EffectComponentAsset& component : asset.components) {
        if (component.id == componentId) {
            return &component;
        }
    }
    return nullptr;
}
