Texture2D<float4> gSceneColor : register(t0);
Texture2D<float4> gVfxAccumulation : register(t1);
Texture2D<float4> gPostColor : register(t2);
SamplerState gSampler : register(s0);

cbuffer CompositeParams : register(b0)
{
    float gBloomIntensity;
    float gDistortionIntensity;
    float gGlowIntensity;
    float gPostIntensity;
};

struct PSInput
{
    float4 position : SV_POSITION;
    float2 uv : TEXCOORD0;
};

float3 Bloom(float3 vfx)
{
    float luminance = dot(vfx, float3(0.2126f, 0.7152f, 0.0722f));
    float threshold = smoothstep(0.35f, 1.25f, luminance);
    return vfx * threshold * 1.6f;
}

float4 main(PSInput input) : SV_TARGET
{
    float2 uv = saturate(input.uv);
    float4 vfx = gVfxAccumulation.Sample(gSampler, uv);

    float2 distortion = (vfx.rg - 0.5f) * vfx.a * 0.012f * gDistortionIntensity;
    float4 scene = gSceneColor.Sample(gSampler, saturate(uv + distortion));
    float4 post = gPostColor.Sample(gSampler, uv);

    float3 bloom = Bloom(vfx.rgb) * gBloomIntensity;
    float3 color = scene.rgb + vfx.rgb * max(vfx.a, 0.35f) * gGlowIntensity + bloom + post.rgb * gPostIntensity;
    color = color / (1.0f + max(color - 1.0f, 0.0f) * 0.35f);
    return float4(saturate(color), 1.0f);
}
