#include "PostProcessStack.h"

void PostProcessStack::ResetToVfxDefaults() {
    passes_.clear();
    passes_.push_back({"BloomExtract", true, 1.0f});
    passes_.push_back({"BlurHorizontal", true, 1.0f});
    passes_.push_back({"BlurVertical", true, 1.0f});
    passes_.push_back({"DistortionComposite", true, 1.0f});
    passes_.push_back({"ToneMapping", true, 1.0f});
    passes_.push_back({"GlowComposite", true, 1.0f});
}

void PostProcessStack::SetEnabled(const std::string& name, bool enabled) {
    for (PostProcessPass& pass : passes_) {
        if (pass.name == name) {
            pass.enabled = enabled;
            return;
        }
    }
}

void PostProcessStack::SetIntensity(const std::string& name, float intensity) {
    for (PostProcessPass& pass : passes_) {
        if (pass.name == name) {
            pass.intensity = intensity;
            return;
        }
    }
}

bool PostProcessStack::IsEnabled(const std::string& name) const {
    for (const PostProcessPass& pass : passes_) {
        if (pass.name == name) {
            return pass.enabled;
        }
    }
    return false;
}

float PostProcessStack::Intensity(const std::string& name) const {
    for (const PostProcessPass& pass : passes_) {
        if (pass.name == name) {
            return pass.enabled ? pass.intensity : 0.0f;
        }
    }
    return 0.0f;
}
