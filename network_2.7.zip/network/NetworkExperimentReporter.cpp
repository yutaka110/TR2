#include "NetworkExperimentReporter.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <filesystem>
#include <iomanip>
#include <fstream>
#include <limits>
#include <sstream>
#include <ctime>
#include <unordered_map>

namespace net {
namespace {

    std::string MakeTimestamp() {
        const auto now = std::chrono::system_clock::now();
        const std::time_t time = std::chrono::system_clock::to_time_t(now);

        std::tm localTime{};
        localtime_s(&localTime, &time);

        std::ostringstream oss;
        oss << std::put_time(&localTime, "%Y%m%d_%H%M%S");
        return oss.str();
    }

    std::string EscapeCsv(std::string value) {
        const bool needsQuote =
            value.find_first_of(",\"\r\n") != std::string::npos;

        if (!needsQuote) {
            return value;
        }

        std::string escaped;
        escaped.reserve(value.size() + 2);
        escaped.push_back('"');

        for (char ch : value) {
            if (ch == '"') {
                escaped.push_back('"');
            }
            escaped.push_back(ch);
        }

        escaped.push_back('"');
        return escaped;
    }

    std::string FormatDouble(double value) {
        std::ostringstream oss;
        oss << std::fixed << std::setprecision(3) << value;
        return oss.str();
    }

    std::string FormatPercent(double ratio) {
        std::ostringstream oss;
        oss << std::fixed << std::setprecision(1) << (ratio * 100.0) << "%";
        return oss.str();
    }

    std::string FormatSignedPercent(double ratio) {
        std::ostringstream oss;
        oss << std::fixed << std::setprecision(1);
        if (ratio > 0.0) {
            oss << '+';
        }
        oss << (ratio * 100.0) << "%";
        return oss.str();
    }

    std::string FormatImprovementRatio(
        double baseline,
        double current,
        bool higherIsBetter
    ) {
        if (std::abs(baseline) < 0.0001) {
            return std::abs(current) < 0.0001 ? "0.0%" : "n/a";
        }

        const double ratio = higherIsBetter
            ? (current - baseline) / baseline
            : (baseline - current) / baseline;
        return FormatSignedPercent(ratio);
    }

    std::string EscapeMarkdownTable(std::string value) {
        for (char& ch : value) {
            if (ch == '|') {
                ch = '/';
            }
            else if (ch == '\r' || ch == '\n') {
                ch = ' ';
            }
        }
        return value;
    }

    std::string EscapeMermaidText(std::string value) {
        for (char& ch : value) {
            if (ch == '"' || ch == '\r' || ch == '\n') {
                ch = ' ';
            }
        }
        return value;
    }

    double ParseDoubleOrDefault(const std::string& value, double fallback = 0.0) {
        if (value.empty()) {
            return fallback;
        }

        char* end = nullptr;
        const double parsed = std::strtod(value.c_str(), &end);
        return end == value.c_str() ? fallback : parsed;
    }

    uint64_t ParseUint64OrDefault(
        const std::string& value,
        uint64_t fallback = 0
    ) {
        if (value.empty()) {
            return fallback;
        }

        char* end = nullptr;
        const unsigned long long parsed =
            std::strtoull(value.c_str(), &end, 10);
        return end == value.c_str()
            ? fallback
            : static_cast<uint64_t>(parsed);
    }

    int ParseIntOrDefault(const std::string& value, int fallback = 0) {
        if (value.empty()) {
            return fallback;
        }

        char* end = nullptr;
        const long parsed = std::strtol(value.c_str(), &end, 10);
        return end == value.c_str() ? fallback : static_cast<int>(parsed);
    }

    std::string FormatDelta(double value) {
        std::ostringstream oss;
        oss << std::fixed << std::setprecision(3);
        if (value > 0.0) {
            oss << '+';
        }
        oss << value;
        return oss.str();
    }

    std::string FormatIntDelta(int64_t value) {
        std::ostringstream oss;
        if (value > 0) {
            oss << '+';
        }
        oss << value;
        return oss.str();
    }

    std::string FormatChangePercent(uint64_t before, uint64_t after) {
        if (before == 0) {
            return after == 0 ? "0.0%" : "n/a";
        }

        const double ratio =
            (static_cast<double>(after) - static_cast<double>(before)) /
            static_cast<double>(before);
        return FormatPercent(ratio);
    }

    size_t AdaptiveCauseIndex(const std::string& cause) {
        if (cause == "Loss") {
            return 1;
        }
        if (cause == "Jitter") {
            return 2;
        }
        if (cause == "RTT") {
            return 3;
        }
        if (cause == "Bandwidth") {
            return 4;
        }
        if (cause == "DecodeLoad") {
            return 5;
        }
        if (cause == "DisplayLoad") {
            return 6;
        }
        if (cause == "PacingQueue") {
            return 7;
        }
        return 0;
    }

    const char* AdaptiveCauseName(size_t index) {
        switch (index) {
        case 1:
            return "Loss";
        case 2:
            return "Jitter";
        case 3:
            return "RTT";
        case 4:
            return "Bandwidth";
        case 5:
            return "DecodeLoad";
        case 6:
            return "DisplayLoad";
        case 7:
            return "PacingQueue";
        case 0:
        default:
            return "None";
        }
    }

    std::string ExtractNetworkScenarioName(const std::string& scenarioName) {
        const std::string marker = " / ";
        const size_t markerPos = scenarioName.find(marker);
        if (markerPos == std::string::npos) {
            return scenarioName;
        }
        return scenarioName.substr(0, markerPos);
    }

} // namespace

    bool NetworkExperimentReporter::Start(const std::string& directory) {
        Stop();

        std::error_code ec;
        std::filesystem::create_directories(directory, ec);
        if (ec) {
            return false;
        }

        const std::string timestamp = MakeTimestamp();
        const std::filesystem::path basePath(directory);
        const std::filesystem::path csvPath =
            basePath / ("network_summary_" + timestamp + ".csv");
        const std::filesystem::path textPath =
            basePath / ("network_summary_" + timestamp + ".txt");
        const std::filesystem::path markdownPath =
            basePath / ("network_report_" + timestamp + ".md");
        const std::filesystem::path beforeAfterPath =
            basePath / ("network_before_after_" + timestamp + ".md");

        csvFile_.open(csvPath, std::ios::out | std::ios::trunc);
        if (!csvFile_) {
            csvFilePath_.clear();
            textFilePath_.clear();
            markdownFilePath_.clear();
            beforeAfterFilePath_.clear();
            previousSummaryCsvPath_.clear();
            generatedTimestamp_.clear();
            summaries_.clear();
            return false;
        }

        textFile_.open(textPath, std::ios::out | std::ios::trunc);
        if (!textFile_) {
            csvFile_.close();
            csvFilePath_.clear();
            textFilePath_.clear();
            markdownFilePath_.clear();
            beforeAfterFilePath_.clear();
            previousSummaryCsvPath_.clear();
            generatedTimestamp_.clear();
            summaries_.clear();
            return false;
        }

        csvFilePath_ = csvPath.string();
        textFilePath_ = textPath.string();
        markdownFilePath_ = markdownPath.string();
        beforeAfterFilePath_ = beforeAfterPath.string();
        previousSummaryCsvPath_ =
            FindPreviousSummaryCsv(directory, csvFilePath_);
        generatedTimestamp_ = timestamp;
        summaries_.clear();
        headerWritten_ = false;
        ResetCurrent();
        WriteHeader();

        textFile_ << "Network Experiment Summary\n";
        textFile_ << "Generated: " << timestamp << "\n\n";
        textFile_.flush();
        WriteMarkdownReport();
        WriteBeforeAfterReport();

        return true;
    }

    void NetworkExperimentReporter::Stop() {
        FinalizeCurrent();

        if (csvFile_.is_open()) {
            csvFile_.flush();
            csvFile_.close();
        }

        if (textFile_.is_open()) {
            textFile_.flush();
            textFile_.close();
        }

        headerWritten_ = false;
        hasCurrent_ = false;
    }

    void NetworkExperimentReporter::RecordSample(
        const std::string& scenarioName,
        const NetworkStatsSnapshot& stats,
        double appTimeSec
    ) {
        if (!csvFile_.is_open() || scenarioName.empty()) {
            return;
        }

        if (!hasCurrent_ || current_.name != scenarioName) {
            FinalizeCurrent();
            ResetCurrent();
            current_.name = scenarioName;
            current_.startTimeSec = appTimeSec;
            current_.minDisplayFps = (std::numeric_limits<double>::max)();
            current_.minTargetFps = (std::numeric_limits<int>::max)();
            current_.minTargetJpegQuality = (std::numeric_limits<int>::max)();
            current_.minTargetBitrateKbps = (std::numeric_limits<int>::max)();
            hasCurrent_ = true;
        }

        current_.endTimeSec = appTimeSec;
        current_.sampleCount++;

        current_.latencySumMs += stats.currentLatencyMs;
        current_.maxLatencyMs =
            (std::max)(current_.maxLatencyMs, stats.currentLatencyMs);
        current_.latencySamplesMs.push_back(stats.currentLatencyMs);

        current_.displayFpsSum += stats.displayFps;
        if (stats.displayFps > 0.0) {
            current_.minDisplayFps =
                (std::min)(current_.minDisplayFps, stats.displayFps);
        }
        current_.receiveFpsSum += stats.receiveFps;
        current_.decodeFpsSum += stats.decodeFps;

        current_.packetLossRateSum += stats.packetLossRate;
        current_.maxPacketLossRate =
            (std::max)(current_.maxPacketLossRate, stats.packetLossRate);

        current_.jitterSumMs += stats.currentJitterMs;
        current_.maxJitterMs =
            (std::max)(current_.maxJitterMs, stats.currentJitterMs);

        if (stats.adaptiveTargetFps > 0) {
            current_.minTargetFps =
                (std::min)(current_.minTargetFps, stats.adaptiveTargetFps);
        }
        if (stats.adaptiveTargetJpegQuality > 0) {
            current_.minTargetJpegQuality =
                (std::min)(current_.minTargetJpegQuality, stats.adaptiveTargetJpegQuality);
        }
        if (stats.adaptiveTargetBitrateKbps > 0) {
            current_.minTargetBitrateKbps =
                (std::min)(current_.minTargetBitrateKbps, stats.adaptiveTargetBitrateKbps);
        }

        if (!stats.networkRuntimeModeName.empty()) {
            if (current_.networkRuntimeMode.empty()) {
                current_.networkRuntimeMode = stats.networkRuntimeModeName;
            }
            else if (current_.networkRuntimeMode != stats.networkRuntimeModeName) {
                current_.networkRuntimeMode = "Mixed";
            }
        }

        if (!stats.adaptiveControlMode.empty()) {
            if (current_.adaptiveControlMode.empty()) {
                current_.adaptiveControlMode = stats.adaptiveControlMode;
            }
            else if (current_.adaptiveControlMode != stats.adaptiveControlMode) {
                current_.adaptiveControlMode = "Mixed";
            }
        }

        if (!stats.adaptiveCongestionControlMode.empty()) {
            if (current_.adaptiveCongestionControlMode.empty()) {
                current_.adaptiveCongestionControlMode =
                    stats.adaptiveCongestionControlMode;
            }
            else if (current_.adaptiveCongestionControlMode !=
                stats.adaptiveCongestionControlMode) {
                current_.adaptiveCongestionControlMode = "Mixed";
            }
        }

        current_.adaptiveCauseSamples[
            AdaptiveCauseIndex(stats.adaptiveDegradationCause)]++;

        TimeSeriesSample timeSeriesSample{};
        timeSeriesSample.relativeTimeSec =
            (std::max)(0.0, appTimeSec - current_.startTimeSec);
        timeSeriesSample.displayFps = stats.displayFps;
        timeSeriesSample.currentLatencyMs = stats.currentLatencyMs;
        timeSeriesSample.rollingP95LatencyMs =
            Percentile(current_.latencySamplesMs, 0.95);
        timeSeriesSample.adaptiveQoeScore = stats.adaptiveLastQoeScore;
        timeSeriesSample.adaptiveDegradationCause =
            stats.adaptiveDegradationCause.empty()
            ? "None"
            : stats.adaptiveDegradationCause;
        timeSeriesSample.adaptiveCauseScore =
            static_cast<double>(
                AdaptiveCauseIndex(timeSeriesSample.adaptiveDegradationCause)) *
            20.0;
        timeSeriesSample.targetJpegQuality =
            stats.adaptiveTargetJpegQuality;
        timeSeriesSample.targetFps = stats.adaptiveTargetFps;
        timeSeriesSample.targetBitrateKbps =
            stats.adaptiveTargetBitrateKbps;
        timeSeriesSample.bandwidthCeilingKbps =
            stats.adaptiveBandwidthCeilingKbps;
        timeSeriesSample.estimatedBandwidthBps =
            stats.estimatedBandwidthBps;
        timeSeriesSample.deliveryRateBps =
            stats.deliveryRateBps;
        timeSeriesSample.bandwidthQueueDelayMs =
            stats.bandwidthQueueDelayMs;
        timeSeriesSample.bandwidthLossTrend =
            stats.bandwidthLossTrend;
        timeSeriesSample.bandwidthJitterTrendMs =
            stats.bandwidthJitterTrendMs;
        timeSeriesSample.deadlineNackSentFrames =
            stats.deadlineNackSentFrames;
        timeSeriesSample.deadlineNackRecoveredFrames =
            stats.deadlineNackRecoveredFrames;
        timeSeriesSample.deadlineNackExpiredDroppedFrames =
            stats.deadlineNackExpiredDroppedFrames;
        timeSeriesSample.ackRetransmittedChunks =
            stats.ackRetransmittedChunks;
        timeSeriesSample.packetLossRate = stats.packetLossRate;
        timeSeriesSample.currentJitterMs = stats.currentJitterMs;
        current_.timeSeriesSamples.push_back(timeSeriesSample);

        current_.lastStats = stats;
    }

    bool NetworkExperimentReporter::IsRunning() const {
        return csvFile_.is_open();
    }

    const std::string& NetworkExperimentReporter::CsvFilePath() const {
        return csvFilePath_;
    }

    const std::string& NetworkExperimentReporter::TextFilePath() const {
        return textFilePath_;
    }

    const std::string& NetworkExperimentReporter::MarkdownFilePath() const {
        return markdownFilePath_;
    }

    const std::string& NetworkExperimentReporter::BeforeAfterFilePath() const {
        return beforeAfterFilePath_;
    }

    void NetworkExperimentReporter::ResetCurrent() {
        current_ = ScenarioAccumulator{};
        hasCurrent_ = false;
    }

    void NetworkExperimentReporter::FinalizeCurrent() {
        if (!hasCurrent_ || current_.sampleCount == 0) {
            return;
        }

        const ScenarioSummary summary = BuildSummary(current_);
        WriteSummary(summary);
        summaries_.push_back(summary);
        WriteMarkdownReport();
        WriteBeforeAfterReport();
        ResetCurrent();
    }

    void NetworkExperimentReporter::WriteHeader() {
        if (!csvFile_.is_open() || headerWritten_) {
            return;
        }

        csvFile_
            << "scenarioName,"
            << "sampleCount,"
            << "startTimeSec,"
            << "endTimeSec,"
            << "durationSec,"
            << "avgLatencyMs,"
            << "p95LatencyMs,"
            << "maxLatencyMs,"
            << "avgDisplayFps,"
            << "minDisplayFps,"
            << "avgReceiveFps,"
            << "avgDecodeFps,"
            << "avgPacketLossRate,"
            << "maxPacketLossRate,"
            << "avgJitterMs,"
            << "maxJitterMs,"
            << "completedFrames,"
            << "displayedFrames,"
            << "droppedFrames,"
            << "deadlineDroppedFrames,"
            << "outputQueueDroppedFrames,"
            << "outputQueueDropEvents,"
            << "outputQueueDropBurstEvents,"
            << "maxOutputQueueDropOldestAgeMs,"
            << "lastOutputQueueDropReason,"
            << "ackCount,"
            << "ackRetransmittedFrames,"
            << "deadlineNackSentFrames,"
            << "deadlineNackRecoveredFrames,"
            << "deadlineNackMissingChunks,"
            << "deadlineNackExpiredDroppedFrames,"
            << "deadlineNackExpiredAfterNackFrames,"
            << "deadlineNackExpiredMissingChunks,"
            << "simDroppedPackets,"
            << "minTargetFps,"
            << "minTargetJpegQuality,"
            << "minTargetBitrateKbps,"
            << "networkRuntimeMode,"
            << "adaptiveControlMode,"
            << "adaptiveCongestionControlMode,"
            << "dominantAdaptiveDegradationCause,"
            << "verdict,"
            << "notes"
            << '\n';

        headerWritten_ = true;
    }

    void NetworkExperimentReporter::WriteSummary(
        const ScenarioSummary& summary
    ) {
        if (csvFile_.is_open()) {
            csvFile_ << std::fixed << std::setprecision(3)
                << EscapeCsv(summary.name) << ','
                << summary.sampleCount << ','
                << summary.startTimeSec << ','
                << summary.endTimeSec << ','
                << summary.durationSec << ','
                << summary.avgLatencyMs << ','
                << summary.p95LatencyMs << ','
                << summary.maxLatencyMs << ','
                << summary.avgDisplayFps << ','
                << summary.minDisplayFps << ','
                << summary.avgReceiveFps << ','
                << summary.avgDecodeFps << ','
                << summary.avgPacketLossRate << ','
                << summary.maxPacketLossRate << ','
                << summary.avgJitterMs << ','
                << summary.maxJitterMs << ','
                << summary.completedFrames << ','
                << summary.displayedFrames << ','
                << summary.droppedFrames << ','
                << summary.deadlineDroppedFrames << ','
                << summary.outputQueueDroppedFrames << ','
                << summary.outputQueueDropEvents << ','
                << summary.outputQueueDropBurstEvents << ','
                << summary.maxOutputQueueDropOldestAgeMs << ','
                << EscapeCsv(summary.lastOutputQueueDropReason) << ','
                << summary.ackCount << ','
                << summary.ackRetransmittedFrames << ','
                << summary.deadlineNackSentFrames << ','
                << summary.deadlineNackRecoveredFrames << ','
                << summary.deadlineNackMissingChunks << ','
                << summary.deadlineNackExpiredDroppedFrames << ','
                << summary.deadlineNackExpiredAfterNackFrames << ','
                << summary.deadlineNackExpiredMissingChunks << ','
                << summary.simDroppedPackets << ','
                << summary.minTargetFps << ','
                << summary.minTargetJpegQuality << ','
                << summary.minTargetBitrateKbps << ','
                << EscapeCsv(summary.networkRuntimeMode) << ','
                << EscapeCsv(summary.adaptiveControlMode) << ','
                << EscapeCsv(summary.adaptiveCongestionControlMode) << ','
                << EscapeCsv(summary.dominantAdaptiveDegradationCause) << ','
                << EscapeCsv(summary.verdict) << ','
                << EscapeCsv(summary.notes)
                << '\n';
            csvFile_.flush();
        }

        if (textFile_.is_open()) {
            textFile_ << "Scenario: " << summary.name << "\n";
            textFile_ << "  samples: " << summary.sampleCount
                << " durationSec: " << FormatDouble(summary.durationSec)
                << "\n";
            textFile_ << "  latency avg/p95/max ms: "
                << FormatDouble(summary.avgLatencyMs) << " / "
                << FormatDouble(summary.p95LatencyMs) << " / "
                << FormatDouble(summary.maxLatencyMs) << "\n";
            textFile_ << "  fps display avg/min: "
                << FormatDouble(summary.avgDisplayFps) << " / "
                << FormatDouble(summary.minDisplayFps) << "\n";
            textFile_ << "  drops deadline/output/total: "
                << summary.deadlineDroppedFrames << " / "
                << summary.outputQueueDroppedFrames << " / "
                << summary.droppedFrames << "\n";
            textFile_ << "  output drop events/burst/maxAge/reason: "
                << summary.outputQueueDropEvents << " / "
                << summary.outputQueueDropBurstEvents << " / "
                << FormatDouble(summary.maxOutputQueueDropOldestAgeMs)
                << " ms / "
                << (summary.lastOutputQueueDropReason.empty()
                    ? "none"
                    : summary.lastOutputQueueDropReason)
                << "\n";
            textFile_ << "  adaptive min fps/quality/bitrate: "
                << summary.minTargetFps << " / "
                << summary.minTargetJpegQuality << " / "
                << summary.minTargetBitrateKbps << "\n";
            textFile_ << "  network runtime mode: "
                << (summary.networkRuntimeMode.empty()
                    ? "unknown"
                    : summary.networkRuntimeMode)
                << "\n";
            textFile_ << "  adaptive control mode: "
                << (summary.adaptiveControlMode.empty()
                    ? "unknown"
                    : summary.adaptiveControlMode)
                << "\n";
            textFile_ << "  congestion control mode: "
                << (summary.adaptiveCongestionControlMode.empty()
                    ? "unknown"
                    : summary.adaptiveCongestionControlMode)
                << "\n";
            textFile_ << "  adaptive dominant cause: "
                << (summary.dominantAdaptiveDegradationCause.empty()
                    ? "None"
                    : summary.dominantAdaptiveDegradationCause)
                << "\n";
            textFile_ << "  deadline nack sent/recovered/missingChunks: "
                << summary.deadlineNackSentFrames << " / "
                << summary.deadlineNackRecoveredFrames << " / "
                << summary.deadlineNackMissingChunks << "\n";
            textFile_ << "  deadline nack expired drops/afterNack/missingChunks: "
                << summary.deadlineNackExpiredDroppedFrames << " / "
                << summary.deadlineNackExpiredAfterNackFrames << " / "
                << summary.deadlineNackExpiredMissingChunks << "\n";
            textFile_ << "  verdict: " << summary.verdict;
            if (!summary.notes.empty()) {
                textFile_ << " (" << summary.notes << ")";
            }
            textFile_ << "\n\n";
            textFile_.flush();
        }
    }

    void NetworkExperimentReporter::WriteMarkdownReport() const {
        if (markdownFilePath_.empty()) {
            return;
        }

        std::ofstream file(markdownFilePath_, std::ios::out | std::ios::trunc);
        if (!file) {
            return;
        }

        uint32_t passCount = 0;
        uint64_t totalDeadlineDrops = 0;
        uint64_t totalOutputQueueDrops = 0;
        uint64_t totalDeadlineNacks = 0;
        uint64_t totalDeadlineNackRecoveries = 0;
        uint64_t totalDeadlineNackMissingChunks = 0;
        uint64_t totalDeadlineNackExpiredDrops = 0;
        double worstP95LatencyMs = 0.0;

        for (const ScenarioSummary& summary : summaries_) {
            if (summary.verdict == "PASS") {
                passCount++;
            }
            totalDeadlineDrops += summary.deadlineDroppedFrames;
            totalOutputQueueDrops += summary.outputQueueDroppedFrames;
            totalDeadlineNacks += summary.deadlineNackSentFrames;
            totalDeadlineNackRecoveries += summary.deadlineNackRecoveredFrames;
            totalDeadlineNackMissingChunks += summary.deadlineNackMissingChunks;
            totalDeadlineNackExpiredDrops +=
                summary.deadlineNackExpiredDroppedFrames;
            worstP95LatencyMs =
                (std::max)(worstP95LatencyMs, summary.p95LatencyMs);
        }

        file << "# Network Experiment Report\n\n";
        file << "Generated: " << generatedTimestamp_ << "\n\n";
        file << "Runtime mode note: Loopback runs sender and receiver in one process for development experiments; Sender transmits camera video only; Receiver rebuilds and displays RNVP frames; Monitor keeps telemetry/reporting visible without sending or displaying video.\n\n";

        file << "## Executive Summary\n\n";
        if (summaries_.empty()) {
            file << "- No completed scenarios yet. The report will be refreshed as scenarios finish.\n\n";
        }
        else {
            const uint32_t warnCount =
                static_cast<uint32_t>(summaries_.size()) - passCount;
            file << "- Completed scenarios: " << summaries_.size()
                << " (" << passCount << " PASS, "
                << warnCount << " WARN).\n";
            file << "- Worst p95 latency: "
                << FormatDouble(worstP95LatencyMs)
                << " ms against the 150 ms display deadline.\n";
            file << "- Deadline drops: " << totalDeadlineDrops
                << ", output queue drops: " << totalOutputQueueDrops << ".\n";
            file << "- NACK recovery expired drops: "
                << totalDeadlineNackExpiredDrops
                << " frames were discarded instead of recovering stale video.\n";

            if (totalDeadlineNacks > 0) {
                const double recoveryRatio =
                    static_cast<double>(totalDeadlineNackRecoveries) /
                    static_cast<double>(totalDeadlineNacks);
                file << "- Selective retransmit recovered "
                    << totalDeadlineNackRecoveries
                    << " incomplete frames after "
                    << totalDeadlineNacks
                    << " deadline NACK events ("
                    << FormatPercent(recoveryRatio)
                    << " frame-level recovery evidence, "
                    << totalDeadlineNackMissingChunks
                    << " missing chunk requests).\n";
            }
            else {
                file << "- Selective retransmit was not needed in completed scenarios.\n";
            }
            file << "\n";
        }

        file << "## Scenario Results\n\n";
        file
            << "| Scenario | Verdict | Runtime | Adaptive Mode | Congestion Mode | Cause | Avg FPS | Min FPS | Avg Latency ms | P95 Latency ms | Deadline Drops | Output Drops | NACK Sent | NACK Recovered | NACK Expired | Notes |\n"
            << "| --- | --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |\n";

        for (const ScenarioSummary& summary : summaries_) {
            file << "| "
                << EscapeMarkdownTable(summary.name) << " | "
                << summary.verdict << " | "
                << EscapeMarkdownTable(
                    summary.networkRuntimeMode.empty()
                    ? "unknown"
                    : summary.networkRuntimeMode) << " | "
                << EscapeMarkdownTable(
                    summary.adaptiveControlMode.empty()
                    ? "unknown"
                    : summary.adaptiveControlMode) << " | "
                << EscapeMarkdownTable(
                    summary.adaptiveCongestionControlMode.empty()
                    ? "unknown"
                    : summary.adaptiveCongestionControlMode) << " | "
                << EscapeMarkdownTable(
                    summary.dominantAdaptiveDegradationCause.empty()
                    ? "None"
                    : summary.dominantAdaptiveDegradationCause) << " | "
                << FormatDouble(summary.avgDisplayFps) << " | "
                << FormatDouble(summary.minDisplayFps) << " | "
                << FormatDouble(summary.avgLatencyMs) << " | "
                << FormatDouble(summary.p95LatencyMs) << " | "
                << summary.deadlineDroppedFrames << " | "
                << summary.outputQueueDroppedFrames << " | "
                << summary.deadlineNackSentFrames << " | "
                << summary.deadlineNackRecoveredFrames << " | "
                << summary.deadlineNackExpiredDroppedFrames << " | "
                << EscapeMarkdownTable(
                    summary.notes.empty() ? "none" : summary.notes)
                << " |\n";
        }
        file << "\n";

        file << "## Controller A/B Comparison\n\n";
        if (summaries_.empty()) {
            file << "No controller comparison is available yet.\n\n";
        }
        else {
            std::vector<std::string> networkScenarioOrder;
            std::unordered_map<std::string, std::vector<const ScenarioSummary*>>
                summariesByNetworkScenario;

            for (const ScenarioSummary& summary : summaries_) {
                const std::string networkScenario =
                    ExtractNetworkScenarioName(summary.name);
                if (summariesByNetworkScenario.find(networkScenario) ==
                    summariesByNetworkScenario.end()) {
                    networkScenarioOrder.push_back(networkScenario);
                }
                summariesByNetworkScenario[networkScenario].push_back(&summary);
            }

            const auto modeName =
                [](const ScenarioSummary& summary) -> std::string {
                const std::string adaptiveMode =
                    summary.adaptiveControlMode.empty()
                    ? std::string("unknown")
                    : summary.adaptiveControlMode;
                if (adaptiveMode == "QoE/Deadline Adaptive" &&
                    !summary.adaptiveCongestionControlMode.empty()) {
                    return adaptiveMode + " / " +
                        summary.adaptiveCongestionControlMode;
                }
                return adaptiveMode;
            };

            const auto isFixedQuality =
                [&](const ScenarioSummary& summary) -> bool {
                return modeName(summary) == "Fixed Quality" ||
                    summary.name.find(" / Fixed Quality") !=
                    std::string::npos;
            };

            const auto frameDropRate =
                [](const ScenarioSummary& summary) -> double {
                const uint64_t totalFrames =
                    summary.displayedFrames + summary.droppedFrames;
                if (totalFrames == 0) {
                    return 0.0;
                }
                return static_cast<double>(summary.droppedFrames) /
                    static_cast<double>(totalFrames);
            };

            const auto averageQoeScore =
                [](const ScenarioSummary& summary) -> double {
                if (summary.timeSeriesSamples.empty()) {
                    return 0.0;
                }

                double sum = 0.0;
                for (const TimeSeriesSample& sample :
                    summary.timeSeriesSamples) {
                    sum += sample.adaptiveQoeScore;
                }
                return sum /
                    static_cast<double>(summary.timeSeriesSamples.size());
            };

            const auto scoreController =
                [&](const ScenarioSummary& summary) -> double {
                double score = summary.p95LatencyMs;
                score += frameDropRate(summary) * 500.0;
                score += static_cast<double>(summary.droppedFrames) * 8.0;
                score += static_cast<double>(summary.deadlineDroppedFrames) *
                    12.0;
                score += static_cast<double>(
                    summary.outputQueueDroppedFrames) * 5.0;
                score += static_cast<double>(
                    summary.deadlineNackExpiredDroppedFrames) * 3.0;
                score -= summary.avgDisplayFps * 0.75;
                score -= averageQoeScore(summary) * 8.0;
                return score;
            };

            file
                << "| Network Scenario | Controller | Frame Drop | Drop vs Fixed | Avg Latency ms | Latency vs Fixed | Display FPS | FPS vs Fixed | Avg QoE | NACK Recovered | NACK Expired | Target FPS | Target JPEG | Verdict |\n"
                << "| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |\n";

            for (const std::string& networkScenario : networkScenarioOrder) {
                const auto it =
                    summariesByNetworkScenario.find(networkScenario);
                if (it == summariesByNetworkScenario.end()) {
                    continue;
                }

                const ScenarioSummary* fixedBaseline = nullptr;
                for (const ScenarioSummary* summary : it->second) {
                    if (isFixedQuality(*summary)) {
                        fixedBaseline = summary;
                        break;
                    }
                }

                for (const ScenarioSummary* summary : it->second) {
                    const double dropRate = frameDropRate(*summary);
                    const double avgQoeScore = averageQoeScore(*summary);
                    const std::string dropVsFixed = fixedBaseline == nullptr
                        ? "n/a"
                        : FormatImprovementRatio(
                            frameDropRate(*fixedBaseline),
                            dropRate,
                            false);
                    const std::string latencyVsFixed = fixedBaseline == nullptr
                        ? "n/a"
                        : FormatImprovementRatio(
                            fixedBaseline->avgLatencyMs,
                            summary->avgLatencyMs,
                            false);
                    const std::string fpsVsFixed = fixedBaseline == nullptr
                        ? "n/a"
                        : FormatImprovementRatio(
                            fixedBaseline->avgDisplayFps,
                            summary->avgDisplayFps,
                            true);

                    file << "| "
                        << EscapeMarkdownTable(networkScenario) << " | "
                        << EscapeMarkdownTable(modeName(*summary)) << " | "
                        << FormatPercent(dropRate) << " | "
                        << dropVsFixed << " | "
                        << FormatDouble(summary->avgLatencyMs) << " | "
                        << latencyVsFixed << " | "
                        << FormatDouble(summary->avgDisplayFps) << " | "
                        << fpsVsFixed << " | "
                        << FormatDouble(avgQoeScore) << " | "
                        << summary->deadlineNackRecoveredFrames << " | "
                        << summary->deadlineNackExpiredDroppedFrames << " | "
                        << summary->minTargetFps << " | "
                        << summary->minTargetJpegQuality << " | "
                        << summary->verdict << " |\n";
                }
            }

            file << "\n";

            file << "### Best Controller By Scenario\n\n";
            file
                << "| Network Scenario | Best Controller | Why It Wins | Fixed Baseline | Evidence |\n"
                << "| --- | --- | --- | --- | --- |\n";

            for (const std::string& networkScenario : networkScenarioOrder) {
                const auto it =
                    summariesByNetworkScenario.find(networkScenario);
                if (it == summariesByNetworkScenario.end() ||
                    it->second.empty()) {
                    continue;
                }

                const ScenarioSummary* fixedBaseline = nullptr;
                const ScenarioSummary* winner = it->second.front();
                double winnerScore = scoreController(*winner);

                for (const ScenarioSummary* candidate : it->second) {
                    if (isFixedQuality(*candidate)) {
                        fixedBaseline = candidate;
                    }

                    const double candidateScore =
                        scoreController(*candidate);
                    if (candidateScore < winnerScore) {
                        winner = candidate;
                        winnerScore = candidateScore;
                    }
                }

                std::string why = "best latency/drop/FPS balance";
                if (winner->p95LatencyMs < 150.0 &&
                    frameDropRate(*winner) <= 0.01) {
                    why = "kept p95 under 150ms with almost no frame drops";
                }
                else if (fixedBaseline != nullptr &&
                    frameDropRate(*winner) < frameDropRate(*fixedBaseline) &&
                    winner->avgDisplayFps >= fixedBaseline->avgDisplayFps) {
                    why = "reduced drops without sacrificing display FPS";
                }
                else if (winner->deadlineNackRecoveredFrames > 0 &&
                    winner->deadlineNackExpiredDroppedFrames <=
                    winner->deadlineNackRecoveredFrames) {
                    why = "recovered missing frames while bounding stale recovery";
                }

                std::string fixedBaselineText = "not available";
                std::string evidence = "score "
                    + FormatDouble(winnerScore);
                if (fixedBaseline != nullptr) {
                    fixedBaselineText =
                        FormatPercent(frameDropRate(*fixedBaseline)) +
                        " drop, " +
                        FormatDouble(fixedBaseline->avgLatencyMs) +
                        " ms latency, " +
                        FormatDouble(fixedBaseline->avgDisplayFps) +
                        " fps";
                    evidence =
                        "drop " +
                        FormatImprovementRatio(
                            frameDropRate(*fixedBaseline),
                            frameDropRate(*winner),
                            false) +
                        ", latency " +
                        FormatImprovementRatio(
                            fixedBaseline->avgLatencyMs,
                            winner->avgLatencyMs,
                            false) +
                        ", fps " +
                        FormatImprovementRatio(
                            fixedBaseline->avgDisplayFps,
                            winner->avgDisplayFps,
                            true) +
                        " vs Fixed";
                }

                file << "| "
                    << EscapeMarkdownTable(networkScenario) << " | "
                    << EscapeMarkdownTable(modeName(*winner)) << " | "
                    << EscapeMarkdownTable(why) << " | "
                    << EscapeMarkdownTable(fixedBaselineText) << " | "
                    << EscapeMarkdownTable(evidence) << " |\n";
            }

            file << "\n";
            file << "### Congestion Control A/B Comparison\n\n";
            file << "This table compares `Loss Based`, `Delay Based`, and `Hybrid` under the same network scenario using only `QoE/Deadline Adaptive` runs.\n\n";
            file
                << "| Network Scenario | Congestion Mode | Frame Drop | Avg Latency ms | P95 Latency ms | Display FPS | Avg QoE | Score |\n"
                << "| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |\n";

            for (const std::string& networkScenario : networkScenarioOrder) {
                const auto it =
                    summariesByNetworkScenario.find(networkScenario);
                if (it == summariesByNetworkScenario.end()) {
                    continue;
                }

                for (const ScenarioSummary* summary : it->second) {
                    if (summary->adaptiveControlMode !=
                        "QoE/Deadline Adaptive") {
                        continue;
                    }

                    file << "| "
                        << EscapeMarkdownTable(networkScenario) << " | "
                        << EscapeMarkdownTable(
                            summary->adaptiveCongestionControlMode.empty()
                            ? "unknown"
                            : summary->adaptiveCongestionControlMode) << " | "
                        << FormatPercent(frameDropRate(*summary)) << " | "
                        << FormatDouble(summary->avgLatencyMs) << " | "
                        << FormatDouble(summary->p95LatencyMs) << " | "
                        << FormatDouble(summary->avgDisplayFps) << " | "
                        << FormatDouble(averageQoeScore(*summary)) << " | "
                        << FormatDouble(scoreController(*summary)) << " |\n";
                }
            }

            file << "\n";
            file << "### Best Congestion Mode By Scenario\n\n";
            file
                << "| Network Scenario | Best Congestion Mode | Why It Wins | Evidence |\n"
                << "| --- | --- | --- | --- |\n";

            for (const std::string& networkScenario : networkScenarioOrder) {
                const auto it =
                    summariesByNetworkScenario.find(networkScenario);
                if (it == summariesByNetworkScenario.end()) {
                    continue;
                }

                const ScenarioSummary* winner = nullptr;
                double winnerScore = 0.0;
                for (const ScenarioSummary* candidate : it->second) {
                    if (candidate->adaptiveControlMode !=
                        "QoE/Deadline Adaptive") {
                        continue;
                    }

                    const double candidateScore =
                        scoreController(*candidate);
                    if (winner == nullptr || candidateScore < winnerScore) {
                        winner = candidate;
                        winnerScore = candidateScore;
                    }
                }

                if (winner == nullptr) {
                    continue;
                }

                std::string why = "best latency/drop/FPS/QoE balance";
                if (winner->adaptiveCongestionControlMode == "Loss Based") {
                    why = "loss-driven AIMD gave the best score";
                }
                else if (winner->adaptiveCongestionControlMode == "Delay Based") {
                    why = "delay-driven AIMD avoided queue growth best";
                }
                else if (winner->adaptiveCongestionControlMode == "Hybrid") {
                    why = "hybrid transport and QoE signals gave the best score";
                }

                const std::string evidence =
                    "drop " + FormatPercent(frameDropRate(*winner)) +
                    ", p95 " + FormatDouble(winner->p95LatencyMs) +
                    " ms, fps " + FormatDouble(winner->avgDisplayFps) +
                    ", score " + FormatDouble(winnerScore);

                file << "| "
                    << EscapeMarkdownTable(networkScenario) << " | "
                    << EscapeMarkdownTable(
                        winner->adaptiveCongestionControlMode.empty()
                        ? "unknown"
                        : winner->adaptiveCongestionControlMode) << " | "
                    << EscapeMarkdownTable(why) << " | "
                    << EscapeMarkdownTable(evidence) << " |\n";
            }

            file << "\n";
            file << "This section is the controller A/B evidence path: Fixed Quality is the uncontrolled baseline, Loss Reactive is packet-loss-only adaptation, and QoE/Deadline Adaptive is evaluated against the same network condition using drop rate, latency, display FPS, QoE, and recovery events.\n\n";
        }

        file << "## Time-Series Controller Response\n\n";
        if (summaries_.empty()) {
            file << "No time-series samples are available yet.\n\n";
        }
        else {
            constexpr size_t kMaxChartSamples = 30;

            const auto shouldPreferScenario =
                [](const ScenarioSummary& summary) -> bool {
                return
                    summary.name == "Baseline / Fixed Quality" ||
                    summary.name == "10% loss / Fixed Quality" ||
                    summary.name == "10% loss / QoE/Deadline Adaptive / Hybrid" ||
                    summary.name == "50ms jitter / QoE/Deadline Adaptive / Delay Based" ||
                    summary.name == "Burst loss / QoE/Deadline Adaptive / Loss Based" ||
                    summary.name == "Burst loss / QoE/Deadline Adaptive / Hybrid";
            };

            std::vector<const ScenarioSummary*> chartSummaries;
            for (const ScenarioSummary& summary : summaries_) {
                if (!summary.timeSeriesSamples.empty() &&
                    shouldPreferScenario(summary)) {
                    chartSummaries.push_back(&summary);
                }
            }
            if (chartSummaries.empty()) {
                for (const ScenarioSummary& summary : summaries_) {
                    if (!summary.timeSeriesSamples.empty()) {
                        chartSummaries.push_back(&summary);
                    }
                    if (chartSummaries.size() >= 4) {
                        break;
                    }
                }
            }

            file << "Selected scenarios are capped at "
                << kMaxChartSamples
                << " points each so the Markdown stays readable while preserving controller reaction trends.\n\n";

            const auto buildNumberArray =
                [](const std::vector<double>& values) -> std::string {
                std::ostringstream oss;
                oss << "[";
                for (size_t i = 0; i < values.size(); ++i) {
                    if (i > 0) {
                        oss << ", ";
                    }
                    oss << FormatDouble(values[i]);
                }
                oss << "]";
                return oss.str();
            };

            const auto collectSamples =
                [&](const ScenarioSummary& summary) {
                std::vector<const TimeSeriesSample*> samples;
                if (summary.timeSeriesSamples.empty()) {
                    return samples;
                }

                const size_t stride =
                    (std::max)(
                        size_t{ 1 },
                        (summary.timeSeriesSamples.size() +
                            kMaxChartSamples - 1) / kMaxChartSamples);

                for (size_t i = 0; i < summary.timeSeriesSamples.size(); i += stride) {
                    samples.push_back(&summary.timeSeriesSamples[i]);
                }

                if (samples.empty() ||
                    samples.back() != &summary.timeSeriesSamples.back()) {
                    samples.push_back(&summary.timeSeriesSamples.back());
                }

                return samples;
            };

            const auto writeChart =
                [&](const std::string& title,
                    const std::string& yLabel,
                    double yMax,
                    const std::vector<double>& xValues,
                    const std::vector<std::pair<std::string, std::vector<double>>>& lines) {
                if (xValues.empty() || lines.empty()) {
                    return;
                }

                file << "```mermaid\n";
                file << "xychart-beta\n";
                file << "  title \"" << EscapeMermaidText(title) << "\"\n";
                file << "  x-axis " << buildNumberArray(xValues) << "\n";
                file << "  y-axis \"" << EscapeMermaidText(yLabel)
                    << "\" 0 --> " << FormatDouble((std::max)(1.0, yMax)) << "\n";
                for (const auto& line : lines) {
                    file << "  line \"" << EscapeMermaidText(line.first)
                        << "\" " << buildNumberArray(line.second) << "\n";
                }
                file << "```\n\n";
            };

            for (const ScenarioSummary* summary : chartSummaries) {
                const std::vector<const TimeSeriesSample*> samples =
                    collectSamples(*summary);
                if (samples.empty()) {
                    continue;
                }

                std::vector<double> x;
                std::vector<double> displayFps;
                std::vector<double> currentLatency;
                std::vector<double> rollingP95Latency;
                std::vector<double> deadlineLine;
                std::vector<double> qoeScoreScaled;
                std::vector<double> causeScore;
                std::vector<double> targetQuality;
                std::vector<double> targetFps;
                std::vector<double> targetBitrateScaled;
                std::vector<double> bandwidthCeilingScaled;
                std::vector<double> estimatedBandwidthMbps;
                std::vector<double> deliveryRateMbps;
                std::vector<double> bandwidthQueueDelayMs;
                std::vector<double> bandwidthLossPercent;
                std::vector<double> bandwidthJitterMs;
                std::vector<double> nackSent;
                std::vector<double> nackRecovered;
                std::vector<double> nackExpired;
                std::vector<double> retransmittedChunks;
                std::vector<double> packetLossPercent;
                std::vector<double> jitterMs;

                double recoveryMax = 1.0;
                double networkInputMax = 10.0;
                double bandwidthMax = 1.0;

                for (const TimeSeriesSample* sample : samples) {
                    x.push_back(sample->relativeTimeSec);
                    displayFps.push_back(sample->displayFps);
                    currentLatency.push_back(sample->currentLatencyMs);
                    rollingP95Latency.push_back(sample->rollingP95LatencyMs);
                    deadlineLine.push_back(150.0);
                    qoeScoreScaled.push_back(sample->adaptiveQoeScore * 20.0);
                    causeScore.push_back(sample->adaptiveCauseScore);
                    targetQuality.push_back(
                        static_cast<double>(sample->targetJpegQuality));
                    targetFps.push_back(static_cast<double>(sample->targetFps));
                    targetBitrateScaled.push_back(
                        static_cast<double>(sample->targetBitrateKbps) / 120.0);
                    bandwidthCeilingScaled.push_back(
                        static_cast<double>(sample->bandwidthCeilingKbps) / 120.0);
                    estimatedBandwidthMbps.push_back(
                        static_cast<double>(sample->estimatedBandwidthBps) /
                        1000.0 / 1000.0);
                    deliveryRateMbps.push_back(
                        static_cast<double>(sample->deliveryRateBps) /
                        1000.0 / 1000.0);
                    bandwidthQueueDelayMs.push_back(
                        sample->bandwidthQueueDelayMs);
                    bandwidthLossPercent.push_back(
                        sample->bandwidthLossTrend * 100.0);
                    bandwidthJitterMs.push_back(
                        sample->bandwidthJitterTrendMs);
                    nackSent.push_back(
                        static_cast<double>(sample->deadlineNackSentFrames));
                    nackRecovered.push_back(
                        static_cast<double>(sample->deadlineNackRecoveredFrames));
                    nackExpired.push_back(
                        static_cast<double>(sample->deadlineNackExpiredDroppedFrames));
                    retransmittedChunks.push_back(
                        static_cast<double>(sample->ackRetransmittedChunks));
                    packetLossPercent.push_back(sample->packetLossRate * 100.0);
                    jitterMs.push_back(sample->currentJitterMs);

                    recoveryMax =
                        (std::max)(recoveryMax, nackSent.back());
                    recoveryMax =
                        (std::max)(recoveryMax, nackRecovered.back());
                    recoveryMax =
                        (std::max)(recoveryMax, nackExpired.back());
                    recoveryMax =
                        (std::max)(recoveryMax, retransmittedChunks.back());
                    networkInputMax =
                        (std::max)(networkInputMax, packetLossPercent.back());
                    networkInputMax =
                        (std::max)(networkInputMax, jitterMs.back());
                    bandwidthMax =
                        (std::max)(bandwidthMax, estimatedBandwidthMbps.back());
                    bandwidthMax =
                        (std::max)(bandwidthMax, deliveryRateMbps.back());
                    bandwidthMax =
                        (std::max)(bandwidthMax, bandwidthQueueDelayMs.back());
                    bandwidthMax =
                        (std::max)(bandwidthMax, bandwidthLossPercent.back());
                    bandwidthMax =
                        (std::max)(bandwidthMax, bandwidthJitterMs.back());
                }

                file << "### " << summary->name << "\n\n";
                file << "Adaptive cause score legend: None=0, Loss=20, Jitter=40, RTT=60, Bandwidth=80, DecodeLoad=100, DisplayLoad=120, PacingQueue=140. Target bitrate and bandwidth ceiling are drawn as `kbps / 120` to share the same axis as quality and FPS.\n\n";

                writeChart(
                    summary->name + " - FPS and Latency",
                    "FPS / ms",
                    160.0,
                    x,
                    {
                        { "Display FPS", displayFps },
                        { "Current latency ms", currentLatency },
                        { "Rolling p95 latency ms", rollingP95Latency },
                        { "150ms deadline", deadlineLine },
                    });

                writeChart(
                    summary->name + " - QoE and Adaptive Cause",
                    "Score",
                    120.0,
                    x,
                    {
                        { "QoE score x20", qoeScoreScaled },
                        { "Cause score", causeScore },
                    });

                writeChart(
                    summary->name + " - Target Quality, FPS, Bitrate",
                    "Control target",
                    100.0,
                    x,
                    {
                        { "JPEG quality", targetQuality },
                        { "Target FPS", targetFps },
                        { "Bitrate kbps / 120", targetBitrateScaled },
                        { "BW ceiling kbps / 120", bandwidthCeilingScaled },
                    });

                writeChart(
                    summary->name + " - Bandwidth Estimator",
                    "Mbps / ms / %",
                    bandwidthMax + 2.0,
                    x,
                    {
                        { "Estimated bandwidth Mbps", estimatedBandwidthMbps },
                        { "Delivery rate Mbps", deliveryRateMbps },
                        { "Queue delay ms", bandwidthQueueDelayMs },
                        { "Loss trend %", bandwidthLossPercent },
                        { "Jitter trend ms", bandwidthJitterMs },
                    });

                writeChart(
                    summary->name + " - Recovery Events",
                    "Count",
                    recoveryMax + 1.0,
                    x,
                    {
                        { "Deadline NACK sent", nackSent },
                        { "NACK recovered", nackRecovered },
                        { "NACK expired", nackExpired },
                        { "Retransmitted chunks", retransmittedChunks },
                    });

                writeChart(
                    summary->name + " - Packet Loss and Jitter",
                    "Loss % / ms",
                    networkInputMax + 5.0,
                    x,
                    {
                        { "Packet loss %", packetLossPercent },
                        { "Jitter ms", jitterMs },
                    });
            }
        }

        file << "## Baseline Comparison\n\n";
        if (summaries_.empty()) {
            file << "No baseline is available yet.\n\n";
        }
        else {
            const ScenarioSummary& baseline = summaries_.front();
            file
                << "| Scenario | Mode | FPS Delta | P95 Latency Delta ms | Drop Delta | Adaptive Min FPS | Adaptive Min JPEG Quality |\n"
                << "| --- | --- | ---: | ---: | ---: | ---: | ---: |\n";

            for (const ScenarioSummary& summary : summaries_) {
                const double fpsDelta =
                    summary.avgDisplayFps - baseline.avgDisplayFps;
                const double p95Delta =
                    summary.p95LatencyMs - baseline.p95LatencyMs;
                const int64_t dropDelta =
                    static_cast<int64_t>(summary.droppedFrames) -
                    static_cast<int64_t>(baseline.droppedFrames);

                file << "| "
                    << EscapeMarkdownTable(summary.name) << " | "
                    << EscapeMarkdownTable(
                        summary.adaptiveControlMode.empty()
                        ? "unknown"
                        : summary.adaptiveControlMode) << " | "
                    << FormatDouble(fpsDelta) << " | "
                    << FormatDouble(p95Delta) << " | "
                    << dropDelta << " | "
                    << summary.minTargetFps << " | "
                    << summary.minTargetJpegQuality << " |\n";
            }
            file << "\n";
        }

        file << "## Automatic Diagnosis\n\n";
        if (summaries_.empty()) {
            file << "- Waiting for experiment data.\n";
        }
        else {
            for (const ScenarioSummary& summary : summaries_) {
                file << "- " << summary.name << ": ";
                if (summary.verdict == "PASS") {
                    file << "deadline and QoE targets stayed healthy";
                }
                else {
                    file << summary.notes;
                }

                if (summary.deadlineNackSentFrames > 0) {
                    file << "; deadline NACK recovered "
                        << summary.deadlineNackRecoveredFrames
                        << " frames from "
                        << summary.deadlineNackSentFrames
                        << " NACK events";
                }

                if (summary.deadlineNackExpiredDroppedFrames > 0) {
                    file << "; "
                        << summary.deadlineNackExpiredDroppedFrames
                        << " stale incomplete frames expired before display deadline";
                }

                if (summary.outputQueueDroppedFrames > 0 &&
                    !summary.lastOutputQueueDropReason.empty()) {
                    file << "; last output-drop reason was "
                        << summary.lastOutputQueueDropReason;
                }

                if (!summary.dominantAdaptiveDegradationCause.empty() &&
                    summary.dominantAdaptiveDegradationCause != "None") {
                    file << "; dominant adaptive cause was "
                        << summary.dominantAdaptiveDegradationCause;
                }

                file << ".\n";
            }
        }

        file << "\n## Interview Summary\n\n";
        if (summaries_.empty()) {
            file << "- Waiting for completed scenarios.\n\n";
        }
        else {
            std::vector<std::string> networkScenarioOrder;
            std::unordered_map<std::string, std::vector<const ScenarioSummary*>>
                summariesByNetworkScenario;

            for (const ScenarioSummary& summary : summaries_) {
                const std::string networkScenario =
                    ExtractNetworkScenarioName(summary.name);
                if (summariesByNetworkScenario.find(networkScenario) ==
                    summariesByNetworkScenario.end()) {
                    networkScenarioOrder.push_back(networkScenario);
                }
                summariesByNetworkScenario[networkScenario].push_back(&summary);
            }

            const auto modeName =
                [](const ScenarioSummary& summary) -> std::string {
                const std::string adaptiveMode =
                    summary.adaptiveControlMode.empty()
                    ? std::string("unknown")
                    : summary.adaptiveControlMode;
                if (adaptiveMode == "QoE/Deadline Adaptive" &&
                    !summary.adaptiveCongestionControlMode.empty()) {
                    return adaptiveMode + " / " +
                        summary.adaptiveCongestionControlMode;
                }
                return adaptiveMode;
            };

            const auto isFixedQuality =
                [&](const ScenarioSummary& summary) -> bool {
                return modeName(summary) == "Fixed Quality" ||
                    summary.name.find(" / Fixed Quality") !=
                    std::string::npos;
            };

            const auto frameDropRate =
                [](const ScenarioSummary& summary) -> double {
                const uint64_t totalFrames =
                    summary.displayedFrames + summary.droppedFrames;
                if (totalFrames == 0) {
                    return 0.0;
                }
                return static_cast<double>(summary.droppedFrames) /
                    static_cast<double>(totalFrames);
            };

            const auto scoreController =
                [&](const ScenarioSummary& summary) -> double {
                double score = summary.p95LatencyMs;
                score += frameDropRate(summary) * 500.0;
                score += static_cast<double>(summary.droppedFrames) * 8.0;
                score += static_cast<double>(summary.deadlineDroppedFrames) *
                    12.0;
                score += static_cast<double>(
                    summary.outputQueueDroppedFrames) * 5.0;
                score += static_cast<double>(
                    summary.deadlineNackExpiredDroppedFrames) * 3.0;
                score -= summary.avgDisplayFps * 0.75;
                return score;
            };

            uint32_t comparableScenarioCount = 0;
            uint32_t adaptiveWinCount = 0;
            double bestDropImprovement = -std::numeric_limits<double>::infinity();
            double bestLatencyImprovement = -std::numeric_limits<double>::infinity();
            double bestFpsImprovement = -std::numeric_limits<double>::infinity();
            std::string bestDropScenario;
            std::string bestLatencyScenario;
            std::string bestFpsScenario;

            for (const std::string& networkScenario : networkScenarioOrder) {
                const auto it =
                    summariesByNetworkScenario.find(networkScenario);
                if (it == summariesByNetworkScenario.end() ||
                    it->second.empty()) {
                    continue;
                }

                const ScenarioSummary* fixedBaseline = nullptr;
                const ScenarioSummary* winner = it->second.front();
                double winnerScore = scoreController(*winner);

                for (const ScenarioSummary* candidate : it->second) {
                    if (isFixedQuality(*candidate)) {
                        fixedBaseline = candidate;
                    }

                    const double candidateScore =
                        scoreController(*candidate);
                    if (candidateScore < winnerScore) {
                        winner = candidate;
                        winnerScore = candidateScore;
                    }
                }

                if (fixedBaseline == nullptr) {
                    continue;
                }

                comparableScenarioCount++;
                if (!isFixedQuality(*winner)) {
                    adaptiveWinCount++;
                }

                const double fixedDropRate = frameDropRate(*fixedBaseline);
                const double winnerDropRate = frameDropRate(*winner);
                const double dropImprovement =
                    std::abs(fixedDropRate) < 0.0001
                    ? 0.0
                    : (fixedDropRate - winnerDropRate) / fixedDropRate;
                const double latencyImprovement =
                    std::abs(fixedBaseline->avgLatencyMs) < 0.0001
                    ? 0.0
                    : (fixedBaseline->avgLatencyMs - winner->avgLatencyMs) /
                    fixedBaseline->avgLatencyMs;
                const double fpsImprovement =
                    std::abs(fixedBaseline->avgDisplayFps) < 0.0001
                    ? 0.0
                    : (winner->avgDisplayFps -
                        fixedBaseline->avgDisplayFps) /
                    fixedBaseline->avgDisplayFps;

                if (dropImprovement > bestDropImprovement) {
                    bestDropImprovement = dropImprovement;
                    bestDropScenario =
                        networkScenario + " / " + modeName(*winner);
                }
                if (latencyImprovement > bestLatencyImprovement) {
                    bestLatencyImprovement = latencyImprovement;
                    bestLatencyScenario =
                        networkScenario + " / " + modeName(*winner);
                }
                if (fpsImprovement > bestFpsImprovement) {
                    bestFpsImprovement = fpsImprovement;
                    bestFpsScenario =
                        networkScenario + " / " + modeName(*winner);
                }
            }

            if (comparableScenarioCount == 0) {
                file << "- Fixed Quality baseline was not found for the completed scenarios. Run the Adaptive A/B experiment so each network condition has Fixed Quality, Loss Reactive, and QoE/Deadline Adaptive rows.\n\n";
            }
            else {
                file << "- Compared " << comparableScenarioCount
                    << " network scenarios against Fixed Quality baselines.\n";
                file << "- Non-fixed adaptive controllers won "
                    << adaptiveWinCount << " / "
                    << comparableScenarioCount
                    << " comparable scenarios by the latency/drop/FPS score.\n";
                file << "- Best frame-drop reduction: "
                    << FormatSignedPercent(bestDropImprovement)
                    << " at " << bestDropScenario << ".\n";
                file << "- Best average-latency improvement: "
                    << FormatSignedPercent(bestLatencyImprovement)
                    << " at " << bestLatencyScenario << ".\n";
                file << "- Best display-FPS improvement: "
                    << FormatSignedPercent(bestFpsImprovement)
                    << " at " << bestFpsScenario << ".\n";
                file << "- Interview framing: under the same network condition, Fixed Quality is the baseline and the adaptive modes are judged by user-visible outcomes: deadline latency, displayed FPS, frame drop rate, QoE, and selective retransmit recovery.\n\n";
            }
        }

        file << "\n## Portfolio Summary\n\n";
        file << "This engine now covers implementation, measurement, evaluation, and improvement in one loop: CSV telemetry records raw runtime behavior, scenario summaries condense each network condition, and this report converts the run into reviewable evidence. Deadline-based NACK and selective retransmission preserve UDP latency while recovering missing chunks when a frame misses its receive deadline.\n";
        file.flush();
    }

    void NetworkExperimentReporter::WriteBeforeAfterReport() const {
        if (beforeAfterFilePath_.empty()) {
            return;
        }

        std::ofstream file(
            beforeAfterFilePath_,
            std::ios::out | std::ios::trunc
        );
        if (!file) {
            return;
        }

        const std::vector<ScenarioSummary> beforeSummaries =
            previousSummaryCsvPath_.empty()
            ? std::vector<ScenarioSummary>{}
            : LoadSummaryCsv(previousSummaryCsvPath_);

        std::unordered_map<std::string, ScenarioSummary> beforeByName;
        for (const ScenarioSummary& summary : beforeSummaries) {
            beforeByName[summary.name] = summary;
        }

        struct ScenarioPair {
            ScenarioSummary before;
            ScenarioSummary after;
        };

        std::vector<ScenarioPair> matched;
        for (const ScenarioSummary& after : summaries_) {
            const auto it = beforeByName.find(after.name);
            if (it != beforeByName.end()) {
                matched.push_back({ it->second, after });
            }
        }

        double beforeFpsSum = 0.0;
        double afterFpsSum = 0.0;
        double beforeP95Sum = 0.0;
        double afterP95Sum = 0.0;
        uint64_t beforeDrops = 0;
        uint64_t afterDrops = 0;
        uint64_t beforeDeadlineDrops = 0;
        uint64_t afterDeadlineDrops = 0;
        uint64_t beforeOutputDrops = 0;
        uint64_t afterOutputDrops = 0;
        uint64_t beforeNackRecovered = 0;
        uint64_t afterNackRecovered = 0;
        uint64_t beforeNackExpired = 0;
        uint64_t afterNackExpired = 0;

        for (const ScenarioPair& pair : matched) {
            beforeFpsSum += pair.before.avgDisplayFps;
            afterFpsSum += pair.after.avgDisplayFps;
            beforeP95Sum += pair.before.p95LatencyMs;
            afterP95Sum += pair.after.p95LatencyMs;
            beforeDrops += pair.before.droppedFrames;
            afterDrops += pair.after.droppedFrames;
            beforeDeadlineDrops += pair.before.deadlineDroppedFrames;
            afterDeadlineDrops += pair.after.deadlineDroppedFrames;
            beforeOutputDrops += pair.before.outputQueueDroppedFrames;
            afterOutputDrops += pair.after.outputQueueDroppedFrames;
            beforeNackRecovered += pair.before.deadlineNackRecoveredFrames;
            afterNackRecovered += pair.after.deadlineNackRecoveredFrames;
            beforeNackExpired +=
                pair.before.deadlineNackExpiredDroppedFrames;
            afterNackExpired +=
                pair.after.deadlineNackExpiredDroppedFrames;
        }

        const double matchedCount =
            (std::max)(1.0, static_cast<double>(matched.size()));
        const double avgFpsDelta =
            matched.empty()
            ? 0.0
            : (afterFpsSum - beforeFpsSum) / matchedCount;
        const double avgP95Delta =
            matched.empty()
            ? 0.0
            : (afterP95Sum - beforeP95Sum) / matchedCount;
        const int64_t dropDelta =
            static_cast<int64_t>(afterDrops) -
            static_cast<int64_t>(beforeDrops);
        const int64_t deadlineDropDelta =
            static_cast<int64_t>(afterDeadlineDrops) -
            static_cast<int64_t>(beforeDeadlineDrops);
        const int64_t outputDropDelta =
            static_cast<int64_t>(afterOutputDrops) -
            static_cast<int64_t>(beforeOutputDrops);
        const int64_t nackRecoveryDelta =
            static_cast<int64_t>(afterNackRecovered) -
            static_cast<int64_t>(beforeNackRecovered);
        const int64_t nackExpiredDelta =
            static_cast<int64_t>(afterNackExpired) -
            static_cast<int64_t>(beforeNackExpired);

        const bool hasLatencyImprovement = avgP95Delta <= -1.0;
        const bool hasDropImprovement = dropDelta < 0;
        const bool hasFpsImprovement = avgFpsDelta >= 1.0;
        const bool hasMeaningfulRegression =
            avgP95Delta >= 5.0 ||
            dropDelta > 3 ||
            avgFpsDelta <= -3.0;

        const char* overallResult = "INCONCLUSIVE";
        if (!matched.empty()) {
            if ((hasLatencyImprovement || hasDropImprovement || hasFpsImprovement) &&
                !hasMeaningfulRegression) {
                overallResult = "IMPROVED";
            }
            else if (hasMeaningfulRegression &&
                !hasLatencyImprovement &&
                !hasDropImprovement) {
                overallResult = "REGRESSED";
            }
            else {
                overallResult = "MIXED";
            }
        }

        file << "# Network Before/After Portfolio Report\n\n";
        file << "Generated: " << generatedTimestamp_ << "\n\n";
        file << "- Before CSV: "
            << (previousSummaryCsvPath_.empty()
                ? "not found"
                : previousSummaryCsvPath_)
            << "\n";
        file << "- After CSV: " << csvFilePath_ << "\n\n";

        file << "## Executive Summary\n\n";
        if (previousSummaryCsvPath_.empty() || beforeSummaries.empty()) {
            file << "- No previous summary CSV was available. Run the experiment at least twice to produce a true before/after comparison.\n\n";
        }
        else if (summaries_.empty()) {
            file << "- Previous summary was loaded, but no scenarios have completed in the current run yet. This report refreshes as each scenario finishes.\n\n";
        }
        else if (matched.empty()) {
            file << "- No matching scenario names were found between the previous and current summaries.\n\n";
        }
        else {
            file << "- Overall result: **" << overallResult << "**.\n";
            file << "- Matched scenarios: " << matched.size() << ".\n";
            file << "- Average display FPS delta: "
                << FormatDelta(avgFpsDelta)
                << " fps.\n";
            file << "- Average p95 latency delta: "
                << FormatDelta(avgP95Delta)
                << " ms.\n";
            file << "- Total drop delta: "
                << FormatIntDelta(dropDelta)
                << " frames ("
                << FormatChangePercent(beforeDrops, afterDrops)
                << " change).\n";
            file << "- Deadline drop delta: "
                << FormatIntDelta(deadlineDropDelta)
                << ", output queue drop delta: "
                << FormatIntDelta(outputDropDelta)
                << ".\n";
            file << "- Deadline NACK recovered-frame delta: "
                << FormatIntDelta(nackRecoveryDelta)
                << " frames.\n";
            file << "- Deadline NACK expired-drop delta: "
                << FormatIntDelta(nackExpiredDelta)
                << " frames.\n\n";
        }

        file << "## Portfolio Snapshot\n\n";
        file
            << "| Item | Summary |\n"
            << "| --- | --- |\n"
            << "| What changed | Compared persisted `network_summary_*.csv` runs and generated a scenario-matched evaluation report. |\n"
            << "| Why it matters | The engine now demonstrates the full implementation -> measurement -> evaluation -> improvement loop expected in realtime networking work. |\n"
            << "| Evidence source | CSV telemetry condensed into scenario summaries, then compared by scenario name and adaptive mode. |\n"
            << "| Primary result | " << overallResult << " across "
            << matched.size() << " matched scenarios. |\n"
            << "| Main trade-off | Low-latency recovery may intentionally expire stale frames instead of displaying late video. |\n\n";

        file << "## Key Metrics\n\n";
        file
            << "| Metric | Before | After | Delta | Interpretation |\n"
            << "| --- | ---: | ---: | ---: | --- |\n";

        file << "| Avg display FPS | "
            << FormatDouble(matched.empty() ? 0.0 : beforeFpsSum / matchedCount)
            << " | "
            << FormatDouble(matched.empty() ? 0.0 : afterFpsSum / matchedCount)
            << " | "
            << FormatDelta(avgFpsDelta)
            << " | "
            << (avgFpsDelta >= 1.0
                ? "smoother display"
                : avgFpsDelta <= -1.0
                ? "lower display rate"
                : "roughly unchanged")
            << " |\n";

        file << "| Avg p95 latency ms | "
            << FormatDouble(matched.empty() ? 0.0 : beforeP95Sum / matchedCount)
            << " | "
            << FormatDouble(matched.empty() ? 0.0 : afterP95Sum / matchedCount)
            << " | "
            << FormatDelta(avgP95Delta)
            << " | "
            << (avgP95Delta <= -1.0
                ? "lower tail latency"
                : avgP95Delta >= 1.0
                ? "higher tail latency"
                : "roughly unchanged")
            << " |\n";

        file << "| Total frame drops | "
            << beforeDrops << " | "
            << afterDrops << " | "
            << FormatIntDelta(dropDelta)
            << " | "
            << (dropDelta < 0
                ? "fewer lost frames"
                : dropDelta > 0
                ? "more dropped frames"
                : "unchanged")
            << " |\n";

        file << "| Deadline drops | "
            << beforeDeadlineDrops << " | "
            << afterDeadlineDrops << " | "
            << FormatIntDelta(deadlineDropDelta)
            << " | display-deadline pressure |\n";

        file << "| Output queue drops | "
            << beforeOutputDrops << " | "
            << afterOutputDrops << " | "
            << FormatIntDelta(outputDropDelta)
            << " | renderer/jitter backlog pressure |\n";

        file << "| NACK recovered frames | "
            << beforeNackRecovered << " | "
            << afterNackRecovered << " | "
            << FormatIntDelta(nackRecoveryDelta)
            << " | selective retransmit recovery evidence |\n";

        file << "| NACK expired drops | "
            << beforeNackExpired << " | "
            << afterNackExpired << " | "
            << FormatIntDelta(nackExpiredDelta)
            << " | stale recovery discarded before missing deadline |\n\n";

        file << "## Scenario Comparison\n\n";
        file
            << "| Scenario | Runtime Before | Runtime After | Mode Before | Mode After | Cause Before | Cause After | FPS Before | FPS After | FPS Delta | P95 Before ms | P95 After ms | P95 Delta ms | Drops Before | Drops After | Drop Delta | Drop Change | NACK Recovered Before | NACK Recovered After | NACK Expired Before | NACK Expired After |\n"
            << "| --- | --- | --- | --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n";

        for (const ScenarioPair& pair : matched) {
            const double fpsDelta =
                pair.after.avgDisplayFps - pair.before.avgDisplayFps;
            const double p95Delta =
                pair.after.p95LatencyMs - pair.before.p95LatencyMs;
            const int64_t dropDelta =
                static_cast<int64_t>(pair.after.droppedFrames) -
                static_cast<int64_t>(pair.before.droppedFrames);

            file << "| "
                << EscapeMarkdownTable(pair.after.name) << " | "
                << EscapeMarkdownTable(
                    pair.before.networkRuntimeMode.empty()
                    ? "unknown"
                    : pair.before.networkRuntimeMode) << " | "
                << EscapeMarkdownTable(
                    pair.after.networkRuntimeMode.empty()
                    ? "unknown"
                    : pair.after.networkRuntimeMode) << " | "
                << EscapeMarkdownTable(
                    pair.before.adaptiveControlMode.empty()
                    ? "unknown"
                    : pair.before.adaptiveControlMode) << " | "
                << EscapeMarkdownTable(
                    pair.after.adaptiveControlMode.empty()
                    ? "unknown"
                    : pair.after.adaptiveControlMode) << " | "
                << EscapeMarkdownTable(
                    pair.before.dominantAdaptiveDegradationCause.empty()
                    ? "None"
                    : pair.before.dominantAdaptiveDegradationCause) << " | "
                << EscapeMarkdownTable(
                    pair.after.dominantAdaptiveDegradationCause.empty()
                    ? "None"
                    : pair.after.dominantAdaptiveDegradationCause) << " | "
                << FormatDouble(pair.before.avgDisplayFps) << " | "
                << FormatDouble(pair.after.avgDisplayFps) << " | "
                << FormatDelta(fpsDelta) << " | "
                << FormatDouble(pair.before.p95LatencyMs) << " | "
                << FormatDouble(pair.after.p95LatencyMs) << " | "
                << FormatDelta(p95Delta) << " | "
                << pair.before.droppedFrames << " | "
                << pair.after.droppedFrames << " | "
                << FormatIntDelta(dropDelta) << " | "
                << FormatChangePercent(
                    pair.before.droppedFrames,
                    pair.after.droppedFrames)
                << " | "
                << pair.before.deadlineNackRecoveredFrames << " | "
                << pair.after.deadlineNackRecoveredFrames << " | "
                << pair.before.deadlineNackExpiredDroppedFrames << " | "
                << pair.after.deadlineNackExpiredDroppedFrames << " |\n";
        }
        file << "\n";

        file << "## After-Run Mode Winners\n\n";
        if (summaries_.empty()) {
            file << "- Waiting for current-run scenarios.\n\n";
        }
        else {
            std::vector<std::string> networkScenarioOrder;
            std::unordered_map<std::string, std::vector<const ScenarioSummary*>>
                summariesByNetworkScenario;

            for (const ScenarioSummary& summary : summaries_) {
                const std::string networkScenario =
                    ExtractNetworkScenarioName(summary.name);
                if (summariesByNetworkScenario.find(networkScenario) ==
                    summariesByNetworkScenario.end()) {
                    networkScenarioOrder.push_back(networkScenario);
                }
                summariesByNetworkScenario[networkScenario].push_back(&summary);
            }

            const auto scoreScenario =
                [](const ScenarioSummary& summary) -> double {
                double score = summary.p95LatencyMs;
                score += static_cast<double>(summary.droppedFrames) * 8.0;
                score += static_cast<double>(summary.deadlineDroppedFrames) * 12.0;
                score += static_cast<double>(summary.outputQueueDroppedFrames) * 5.0;
                score += static_cast<double>(
                    summary.deadlineNackExpiredDroppedFrames) * 3.0;
                score -= summary.avgDisplayFps * 0.75;
                return score;
            };

            file
                << "| Network Scenario | Best Mode | Why It Wins | FPS | P95 Latency ms | Drops | NACK Recovered | Trade-off |\n"
                << "| --- | --- | --- | ---: | ---: | ---: | ---: | --- |\n";

            for (const std::string& networkScenario : networkScenarioOrder) {
                const auto it =
                    summariesByNetworkScenario.find(networkScenario);
                if (it == summariesByNetworkScenario.end() ||
                    it->second.empty()) {
                    continue;
                }

                const ScenarioSummary* winner = it->second.front();
                double winnerScore = scoreScenario(*winner);
                for (const ScenarioSummary* candidate : it->second) {
                    const double candidateScore = scoreScenario(*candidate);
                    if (candidateScore < winnerScore) {
                        winner = candidate;
                        winnerScore = candidateScore;
                    }
                }

                std::string why = "best latency/drop balance";
                if (winner->droppedFrames == 0 &&
                    winner->p95LatencyMs < 150.0) {
                    why = "met the 150ms deadline with no frame drops";
                }
                else if (winner->deadlineNackRecoveredFrames > 0 &&
                    winner->droppedFrames <= winner->deadlineNackRecoveredFrames) {
                    why = "used selective retransmit while keeping drops bounded";
                }
                else if (winner->avgDisplayFps >= 24.0 &&
                    winner->p95LatencyMs < 150.0) {
                    why = "kept interactive FPS under the latency deadline";
                }

                std::string tradeoff = "none observed";
                if (winner->minTargetJpegQuality <= 40 ||
                    winner->minTargetFps <= 8) {
                    tradeoff = "quality or FPS reached the lower adaptive bound";
                }
                else if (winner->deadlineNackExpiredDroppedFrames > 0) {
                    tradeoff = "expired stale recovery to protect latency";
                }
                else if (winner->avgDisplayFps < 20.0) {
                    tradeoff = "lower display FPS";
                }

                file << "| "
                    << EscapeMarkdownTable(networkScenario) << " | "
                    << EscapeMarkdownTable(
                        winner->adaptiveControlMode.empty()
                        ? "unknown"
                        : winner->adaptiveControlMode) << " | "
                    << EscapeMarkdownTable(why) << " | "
                    << FormatDouble(winner->avgDisplayFps) << " | "
                    << FormatDouble(winner->p95LatencyMs) << " | "
                    << winner->droppedFrames << " | "
                    << winner->deadlineNackRecoveredFrames << " | "
                    << EscapeMarkdownTable(tradeoff) << " |\n";
            }

            file << "\n";
        }

        file << "## Automatic Evaluation\n\n";
        if (matched.empty()) {
            file << "- Waiting for comparable scenarios.\n";
        }
        else {
            for (const ScenarioPair& pair : matched) {
                const double fpsDelta =
                    pair.after.avgDisplayFps - pair.before.avgDisplayFps;
                const double p95Delta =
                    pair.after.p95LatencyMs - pair.before.p95LatencyMs;
                const int64_t dropDelta =
                    static_cast<int64_t>(pair.after.droppedFrames) -
                    static_cast<int64_t>(pair.before.droppedFrames);
                const int64_t nackRecoveryDelta =
                    static_cast<int64_t>(pair.after.deadlineNackRecoveredFrames) -
                    static_cast<int64_t>(pair.before.deadlineNackRecoveredFrames);
                const int64_t nackExpiredDelta =
                    static_cast<int64_t>(pair.after.deadlineNackExpiredDroppedFrames) -
                    static_cast<int64_t>(pair.before.deadlineNackExpiredDroppedFrames);

                file << "- " << pair.after.name << ": ";

                bool wroteFinding = false;
                if (fpsDelta >= 1.0) {
                    file << "display FPS improved by "
                        << FormatDouble(fpsDelta) << " fps";
                    wroteFinding = true;
                }
                else if (fpsDelta <= -1.0) {
                    file << "display FPS regressed by "
                        << FormatDouble(-fpsDelta) << " fps";
                    wroteFinding = true;
                }

                if (p95Delta <= -1.0) {
                    file << (wroteFinding ? "; " : "")
                        << "p95 latency improved by "
                        << FormatDouble(-p95Delta) << " ms";
                    wroteFinding = true;
                }
                else if (p95Delta >= 1.0) {
                    file << (wroteFinding ? "; " : "")
                        << "p95 latency regressed by "
                        << FormatDouble(p95Delta) << " ms";
                    wroteFinding = true;
                }

                if (dropDelta < 0) {
                    file << (wroteFinding ? "; " : "")
                        << "frame drops reduced by "
                        << -dropDelta;
                    wroteFinding = true;
                }
                else if (dropDelta > 0) {
                    file << (wroteFinding ? "; " : "")
                        << "frame drops increased by "
                        << dropDelta;
                    wroteFinding = true;
                }

                if (nackRecoveryDelta > 0) {
                    file << (wroteFinding ? "; " : "")
                        << "selective retransmit recovered "
                        << nackRecoveryDelta
                        << " more frames";
                    wroteFinding = true;
                }

                if (nackExpiredDelta > 0) {
                    file << (wroteFinding ? "; " : "")
                        << "stale NACK recovery expired "
                        << nackExpiredDelta
                        << " more frames before display deadline";
                    wroteFinding = true;
                }

                if (!wroteFinding) {
                    file << "no material metric change";
                }

                file << ".\n";
            }
        }

        file << "\n## Interview-Ready Summary\n\n";
        file << "### What Changed\n\n";
        file << "The engine compares two persisted experiment runs directly from `network_summary_*.csv`, matches scenarios by name, and reports FPS, p95 latency, frame drops, deadline drops, output queue drops, NACK recovery, and stale-recovery expiry.\n\n";

        file << "### Why It Matters\n\n";
        file << "Realtime video networking is not only about sending packets. This report shows whether reliability and adaptive-control changes actually improved the user-visible pipeline under repeatable network conditions.\n\n";

        file << "### Evidence\n\n";
        if (matched.empty()) {
            file << "No matching scenarios are available yet. Run the same automatic experiment sequence twice to populate this section with true before/after evidence.\n\n";
        }
        else {
            file << "- Overall result: " << overallResult << ".\n";
            file << "- Average display FPS delta: "
                << FormatDelta(avgFpsDelta) << " fps.\n";
            file << "- Average p95 latency delta: "
                << FormatDelta(avgP95Delta) << " ms.\n";
            file << "- Total frame drop delta: "
                << FormatIntDelta(dropDelta) << " frames.\n";
            file << "- NACK recovered-frame delta: "
                << FormatIntDelta(nackRecoveryDelta) << " frames.\n\n";
        }

        file << "### Trade-Off\n\n";
        file << "The low-latency policy may drop or expire incomplete frames that cannot arrive before the display deadline. That is intentional for interactive video: a late frame is less useful than a fresh frame.\n\n";

        file << "### Next Improvement\n\n";
        file << "The next portfolio-level step is to add time-series charts for FPS, p95 latency, QoE score, target quality, and recovery events so the report shows both summary evidence and how the controller reacted over time.\n";
        file.flush();
    }

    std::string NetworkExperimentReporter::FindPreviousSummaryCsv(
        const std::string& directory,
        const std::string& currentCsvPath
    ) {
        std::error_code ec;
        const std::filesystem::path currentPath =
            std::filesystem::absolute(currentCsvPath, ec).lexically_normal();

        std::vector<
            std::pair<std::filesystem::file_time_type, std::string>
        > candidates;

        for (const std::filesystem::directory_entry& entry :
            std::filesystem::directory_iterator(directory, ec)) {
            if (ec) {
                break;
            }

            if (!entry.is_regular_file(ec)) {
                continue;
            }

            const std::filesystem::path path = entry.path();
            const std::string fileName = path.filename().string();
            if (fileName.rfind("network_summary_", 0) != 0 ||
                path.extension() != ".csv") {
                continue;
            }

            if (entry.file_size(ec) == 0) {
                continue;
            }

            const std::filesystem::path absolutePath =
                std::filesystem::absolute(path, ec).lexically_normal();
            if (!ec && absolutePath == currentPath) {
                continue;
            }

            const std::filesystem::file_time_type writeTime =
                entry.last_write_time(ec);
            if (ec) {
                continue;
            }

            candidates.emplace_back(writeTime, path.string());
        }

        if (candidates.empty()) {
            return {};
        }

        std::sort(
            candidates.begin(),
            candidates.end(),
            [](const auto& lhs, const auto& rhs) {
                return lhs.first > rhs.first;
            }
        );

        return candidates.front().second;
    }

    std::vector<NetworkExperimentReporter::ScenarioSummary>
        NetworkExperimentReporter::LoadSummaryCsv(const std::string& path) {
        std::ifstream file(path);
        if (!file) {
            return {};
        }

        std::string headerLine;
        if (!std::getline(file, headerLine)) {
            return {};
        }

        const std::vector<std::string> headers = ParseCsvLine(headerLine);
        std::unordered_map<std::string, size_t> columns;
        for (size_t i = 0; i < headers.size(); ++i) {
            columns[headers[i]] = i;
        }

        const auto getCell = [&columns](const std::vector<std::string>& row,
            const std::string& name) -> std::string {
            const auto it = columns.find(name);
            if (it == columns.end() || it->second >= row.size()) {
                return {};
            }
            return row[it->second];
        };

        std::vector<ScenarioSummary> summaries;
        std::string line;
        while (std::getline(file, line)) {
            if (line.empty()) {
                continue;
            }

            const std::vector<std::string> row = ParseCsvLine(line);
            ScenarioSummary summary{};
            summary.name = getCell(row, "scenarioName");
            if (summary.name.empty()) {
                continue;
            }

            summary.sampleCount = static_cast<uint32_t>(
                ParseUint64OrDefault(getCell(row, "sampleCount")));
            summary.startTimeSec =
                ParseDoubleOrDefault(getCell(row, "startTimeSec"));
            summary.endTimeSec =
                ParseDoubleOrDefault(getCell(row, "endTimeSec"));
            summary.durationSec =
                ParseDoubleOrDefault(getCell(row, "durationSec"));
            summary.avgLatencyMs =
                ParseDoubleOrDefault(getCell(row, "avgLatencyMs"));
            summary.p95LatencyMs =
                ParseDoubleOrDefault(getCell(row, "p95LatencyMs"));
            summary.maxLatencyMs =
                ParseDoubleOrDefault(getCell(row, "maxLatencyMs"));
            summary.avgDisplayFps =
                ParseDoubleOrDefault(getCell(row, "avgDisplayFps"));
            summary.minDisplayFps =
                ParseDoubleOrDefault(getCell(row, "minDisplayFps"));
            summary.avgReceiveFps =
                ParseDoubleOrDefault(getCell(row, "avgReceiveFps"));
            summary.avgDecodeFps =
                ParseDoubleOrDefault(getCell(row, "avgDecodeFps"));
            summary.avgPacketLossRate =
                ParseDoubleOrDefault(getCell(row, "avgPacketLossRate"));
            summary.maxPacketLossRate =
                ParseDoubleOrDefault(getCell(row, "maxPacketLossRate"));
            summary.avgJitterMs =
                ParseDoubleOrDefault(getCell(row, "avgJitterMs"));
            summary.maxJitterMs =
                ParseDoubleOrDefault(getCell(row, "maxJitterMs"));
            summary.completedFrames =
                ParseUint64OrDefault(getCell(row, "completedFrames"));
            summary.displayedFrames =
                ParseUint64OrDefault(getCell(row, "displayedFrames"));
            summary.droppedFrames =
                ParseUint64OrDefault(getCell(row, "droppedFrames"));
            summary.deadlineDroppedFrames =
                ParseUint64OrDefault(getCell(row, "deadlineDroppedFrames"));
            summary.outputQueueDroppedFrames =
                ParseUint64OrDefault(getCell(row, "outputQueueDroppedFrames"));
            summary.outputQueueDropEvents =
                ParseUint64OrDefault(getCell(row, "outputQueueDropEvents"));
            summary.outputQueueDropBurstEvents =
                ParseUint64OrDefault(
                    getCell(row, "outputQueueDropBurstEvents"));
            summary.maxOutputQueueDropOldestAgeMs =
                ParseDoubleOrDefault(
                    getCell(row, "maxOutputQueueDropOldestAgeMs"));
            summary.lastOutputQueueDropReason =
                getCell(row, "lastOutputQueueDropReason");
            summary.ackCount =
                ParseUint64OrDefault(getCell(row, "ackCount"));
            summary.ackRetransmittedFrames =
                ParseUint64OrDefault(getCell(row, "ackRetransmittedFrames"));
            summary.deadlineNackSentFrames =
                ParseUint64OrDefault(getCell(row, "deadlineNackSentFrames"));
            summary.deadlineNackRecoveredFrames =
                ParseUint64OrDefault(
                    getCell(row, "deadlineNackRecoveredFrames"));
            summary.deadlineNackMissingChunks =
                ParseUint64OrDefault(
                    getCell(row, "deadlineNackMissingChunks"));
            summary.deadlineNackExpiredDroppedFrames =
                ParseUint64OrDefault(
                    getCell(row, "deadlineNackExpiredDroppedFrames"));
            summary.deadlineNackExpiredAfterNackFrames =
                ParseUint64OrDefault(
                    getCell(row, "deadlineNackExpiredAfterNackFrames"));
            summary.deadlineNackExpiredMissingChunks =
                ParseUint64OrDefault(
                    getCell(row, "deadlineNackExpiredMissingChunks"));
            summary.simDroppedPackets =
                ParseUint64OrDefault(getCell(row, "simDroppedPackets"));
            summary.minTargetFps =
                ParseIntOrDefault(getCell(row, "minTargetFps"));
            summary.minTargetJpegQuality =
                ParseIntOrDefault(getCell(row, "minTargetJpegQuality"));
            summary.minTargetBitrateKbps =
                ParseIntOrDefault(getCell(row, "minTargetBitrateKbps"));
            summary.networkRuntimeMode =
                getCell(row, "networkRuntimeMode");
            summary.adaptiveControlMode =
                getCell(row, "adaptiveControlMode");
            summary.adaptiveCongestionControlMode =
                getCell(row, "adaptiveCongestionControlMode");
            summary.dominantAdaptiveDegradationCause =
                getCell(row, "dominantAdaptiveDegradationCause");
            summary.verdict = getCell(row, "verdict");
            summary.notes = getCell(row, "notes");

            summaries.push_back(summary);
        }

        return summaries;
    }

    std::vector<std::string> NetworkExperimentReporter::ParseCsvLine(
        const std::string& line
    ) {
        std::vector<std::string> cells;
        std::string cell;
        bool inQuotes = false;

        for (size_t i = 0; i < line.size(); ++i) {
            const char ch = line[i];

            if (inQuotes) {
                if (ch == '"') {
                    if (i + 1 < line.size() && line[i + 1] == '"') {
                        cell.push_back('"');
                        i++;
                    }
                    else {
                        inQuotes = false;
                    }
                }
                else {
                    cell.push_back(ch);
                }
                continue;
            }

            if (ch == '"') {
                inQuotes = true;
            }
            else if (ch == ',') {
                cells.push_back(cell);
                cell.clear();
            }
            else {
                cell.push_back(ch);
            }
        }

        cells.push_back(cell);
        return cells;
    }

    NetworkExperimentReporter::ScenarioSummary
        NetworkExperimentReporter::BuildSummary(
            const ScenarioAccumulator& current
        ) {
        ScenarioSummary summary{};
        summary.name = current.name;
        summary.sampleCount = current.sampleCount;
        summary.startTimeSec = current.startTimeSec;
        summary.endTimeSec = current.endTimeSec;
        summary.durationSec =
            (std::max)(0.0, current.endTimeSec - current.startTimeSec);

        const double sampleCount =
            (std::max)(1.0, static_cast<double>(current.sampleCount));

        summary.avgLatencyMs = current.latencySumMs / sampleCount;
        summary.p95LatencyMs =
            Percentile(current.latencySamplesMs, 0.95);
        summary.maxLatencyMs = current.maxLatencyMs;

        summary.avgDisplayFps = current.displayFpsSum / sampleCount;
        summary.minDisplayFps =
            current.minDisplayFps == (std::numeric_limits<double>::max)()
            ? 0.0
            : current.minDisplayFps;
        summary.avgReceiveFps = current.receiveFpsSum / sampleCount;
        summary.avgDecodeFps = current.decodeFpsSum / sampleCount;

        summary.avgPacketLossRate = current.packetLossRateSum / sampleCount;
        summary.maxPacketLossRate = current.maxPacketLossRate;
        summary.avgJitterMs = current.jitterSumMs / sampleCount;
        summary.maxJitterMs = current.maxJitterMs;

        summary.completedFrames = current.lastStats.completedFrames;
        summary.displayedFrames = current.lastStats.displayedFrames;
        summary.droppedFrames = current.lastStats.droppedFrames;
        summary.deadlineDroppedFrames =
            current.lastStats.deadlineDroppedFrames;
        summary.outputQueueDroppedFrames =
            current.lastStats.outputQueueDroppedFrames;
        summary.outputQueueDropEvents =
            current.lastStats.outputQueueDropEvents;
        summary.outputQueueDropBurstEvents =
            current.lastStats.outputQueueDropBurstEvents;
        summary.maxOutputQueueDropOldestAgeMs =
            current.lastStats.maxOutputQueueDropOldestAgeMs;
        summary.lastOutputQueueDropReason =
            current.lastStats.lastOutputQueueDropReason;
        summary.ackCount = current.lastStats.ackCount;
        summary.ackRetransmittedFrames =
            current.lastStats.ackRetransmittedFrames;
        summary.deadlineNackSentFrames =
            current.lastStats.deadlineNackSentFrames;
        summary.deadlineNackRecoveredFrames =
            current.lastStats.deadlineNackRecoveredFrames;
        summary.deadlineNackMissingChunks =
            current.lastStats.deadlineNackMissingChunks;
        summary.deadlineNackExpiredDroppedFrames =
            current.lastStats.deadlineNackExpiredDroppedFrames;
        summary.deadlineNackExpiredAfterNackFrames =
            current.lastStats.deadlineNackExpiredAfterNackFrames;
        summary.deadlineNackExpiredMissingChunks =
            current.lastStats.deadlineNackExpiredMissingChunks;
        summary.simDroppedPackets =
            current.lastStats.networkSimulation.droppedPackets;

        summary.minTargetFps =
            current.minTargetFps == (std::numeric_limits<int>::max)()
            ? 0
            : current.minTargetFps;
        summary.minTargetJpegQuality =
            current.minTargetJpegQuality == (std::numeric_limits<int>::max)()
            ? 0
            : current.minTargetJpegQuality;
        summary.minTargetBitrateKbps =
            current.minTargetBitrateKbps == (std::numeric_limits<int>::max)()
            ? 0
            : current.minTargetBitrateKbps;
        summary.networkRuntimeMode = current.networkRuntimeMode;
        summary.adaptiveControlMode = current.adaptiveControlMode;
        summary.adaptiveCongestionControlMode =
            current.adaptiveCongestionControlMode;

        size_t dominantCauseIndex = 0;
        uint32_t dominantCauseSamples = 0;
        for (size_t i = 0; i < current.adaptiveCauseSamples.size(); ++i) {
            if (current.adaptiveCauseSamples[i] > dominantCauseSamples) {
                dominantCauseSamples = current.adaptiveCauseSamples[i];
                dominantCauseIndex = i;
            }
        }
        summary.dominantAdaptiveDegradationCause =
            AdaptiveCauseName(dominantCauseIndex);
        summary.timeSeriesSamples = current.timeSeriesSamples;

        summary.notes = BuildVerdictNotes(summary);
        summary.verdict = summary.notes.empty() ? "PASS" : "WARN";

        return summary;
    }

    double NetworkExperimentReporter::Percentile(
        std::vector<double> values,
        double percentile
    ) {
        if (values.empty()) {
            return 0.0;
        }

        std::sort(values.begin(), values.end());

        const double clamped =
            (std::max)(0.0, (std::min)(1.0, percentile));
        const double rawIndex =
            clamped * static_cast<double>(values.size() - 1);
        const size_t lowerIndex = static_cast<size_t>(std::floor(rawIndex));
        const size_t upperIndex = static_cast<size_t>(std::ceil(rawIndex));

        if (lowerIndex == upperIndex) {
            return values[lowerIndex];
        }

        const double t = rawIndex - static_cast<double>(lowerIndex);
        return values[lowerIndex] * (1.0 - t) + values[upperIndex] * t;
    }

    std::string NetworkExperimentReporter::BuildVerdictNotes(
        const ScenarioSummary& summary
    ) {
        std::vector<std::string> notes;

        if (summary.p95LatencyMs >= 150.0) {
            notes.push_back("p95 latency reached 150ms deadline");
        }
        else if (summary.p95LatencyMs >= 135.0) {
            notes.push_back("p95 latency is near 150ms deadline");
        }

        if (summary.deadlineDroppedFrames > 1) {
            notes.push_back("deadline drops observed");
        }

        if (summary.outputQueueDroppedFrames > 0) {
            if (summary.outputQueueDropBurstEvents > 0 &&
                summary.outputQueueDropBurstEvents >= summary.outputQueueDropEvents) {
                notes.push_back("output drops likely from jitter burst release");
            }
            else if (summary.lastOutputQueueDropReason == "renderer-lag") {
                notes.push_back("output drops likely from render/decode lag");
            }
            else {
                notes.push_back("output queue drops observed");
            }
        }

        if (summary.minTargetFps > 0 &&
            summary.avgDisplayFps <
            static_cast<double>(summary.minTargetFps) * 0.75) {
            notes.push_back("display fps below adaptive target");
        }

        if (summary.minTargetFps <= 8 || summary.minTargetJpegQuality <= 40) {
            notes.push_back("adaptive reached minimum quality");
        }

        std::ostringstream oss;
        for (size_t i = 0; i < notes.size(); ++i) {
            if (i > 0) {
                oss << "; ";
            }
            oss << notes[i];
        }

        return oss.str();
    }

} // namespace net
