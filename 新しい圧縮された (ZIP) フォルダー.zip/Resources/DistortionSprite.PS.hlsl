Texture2D gDistortionTex : register(t0);
SamplerState gSampler : register(s0);

struct PSIn
{
    float4 position : SV_POSITION;
    float2 texcoord : TEXCOORD;
    float4 color : COLOR0;
};

float4 main(PSIn input) : SV_TARGET
{
    float4 tex = gDistortionTex.Sample(gSampler, input.texcoord);
    float2 centered = input.texcoord - 0.5f;
    float radial = length(centered) * 2.0f;
    float ring = smoothstep(1.0f, 0.15f, radial) * smoothstep(0.0f, 0.45f, radial);
    float noise = tex.r * 2.0f - 1.0f;

    float2 dir = radial > 0.001f ? centered / max(radial * 0.5f, 0.001f) : float2(0.0f, 0.0f);
    float2 offset = dir * (0.5f + noise * 0.35f) * input.color.a;

    float alpha = ring * saturate(input.color.a + tex.a * 0.5f);
    return float4(0.5f + offset * 0.5f, 0.0f, alpha);
}
