#pragma once

#include <cstdint>
#include <d3d12.h>
#include <wrl/client.h>

#include "core/DescriptorHeap.h"
#include "resources/ResourceRegistry.h"

class AppVfxRenderTargets {
public:
    bool Initialize(
        ID3D12Device* device,
        ge3::core::DescriptorHeapSet& heaps,
        uint32_t width,
        uint32_t height);

    void Register(ge3::resources::ResourceRegistry& registry) const;
    void BeginScene(ID3D12GraphicsCommandList* commandList, D3D12_CPU_DESCRIPTOR_HANDLE dsv);
    void BeginVfx(ID3D12GraphicsCommandList* commandList, D3D12_CPU_DESCRIPTOR_HANDLE dsv);
    void CompositeToBackBuffer(
        ID3D12GraphicsCommandList* commandList,
        ID3D12Resource* backBuffer,
        D3D12_CPU_DESCRIPTOR_HANDLE backBufferRtv,
        ID3D12RootSignature* rootSignature,
        ID3D12PipelineState* pipelineState,
        const float compositeParams[4]);

    bool IsInitialized() const { return initialized_; }

private:
    struct Target {
        Microsoft::WRL::ComPtr<ID3D12Resource> resource;
        ge3::core::DescriptorHandle rtv{};
        ge3::core::DescriptorHandle srv{};
        D3D12_RESOURCE_STATES state = D3D12_RESOURCE_STATE_COMMON;
    };

    bool CreateTarget(
        ID3D12Device* device,
        ge3::core::DescriptorHeapSet& heaps,
        const char* name,
        uint32_t width,
        uint32_t height,
        const float clearColor[4],
        Target& target);
    void Transition(
        ID3D12GraphicsCommandList* commandList,
        Target& target,
        D3D12_RESOURCE_STATES after);

    Target sceneColor_{};
    Target vfxAccumulation_{};
    Target postColor_{};
    uint32_t width_ = 0;
    uint32_t height_ = 0;
    bool initialized_ = false;
};
