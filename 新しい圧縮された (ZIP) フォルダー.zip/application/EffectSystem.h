#pragma once

#include <cstdint>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

#include "graphics/MaterialBinding.h"
#include "utils/math/MathUtils.h"

enum class EffectLayer {
    OpaqueFx,
    AdditiveFx,
    DistortionFx,
    TrailFx,
    VolumetricFx,
};

enum class EffectComponentType {
    Particle,
    Trail,
    Beam,
    Distortion,
};

struct EffectComponentAsset {
    uint32_t id = 0;
    EffectComponentType type = EffectComponentType::Particle;
    std::string name;
    std::string shader;
    std::string texture;
    ge3::graphics::PassState passState{};
    EffectLayer layer = EffectLayer::AdditiveFx;
    float startTime = 0.0f;
    float duration = 1.0f;
    float emissive = 1.0f;
    float distortionStrength = 0.0f;
    float noiseStrength = 0.0f;
    float uvScrollSpeed = 0.0f;
    float pulseSpeed = 5.0f;
    float spawnRadius = 4.0f;
    Vector4 color = {1.0f, 1.0f, 1.0f, 1.0f};
    Vector3 size = {1.0f, 1.0f, 1.0f};
};

struct EffectAsset {
    std::string name;
    std::string shader;
    std::string texture;
    ge3::graphics::PassState passState{};
    EffectLayer layer = EffectLayer::AdditiveFx;
    float lifetime = 1.0f;
    float emissive = 1.0f;
    float distortionStrength = 0.0f;
    float noiseStrength = 0.0f;
    float uvScrollSpeed = 0.0f;
    float pulseSpeed = 5.0f;
    float spawnRadius = 4.0f;
    Vector4 color = {1.0f, 1.0f, 1.0f, 1.0f};
    Vector3 size = {1.0f, 1.0f, 1.0f};
    std::vector<EffectComponentAsset> components;
};

struct EffectComponentInstance {
    uint32_t componentId = 0;
    float age = 0.0f;
    bool active = true;
};

struct EffectInstance {
    uint32_t id = 0;
    std::string assetName;
    const EffectAsset* asset = nullptr;
    std::vector<EffectComponentInstance> components;
    Transform transform{};
    Vector4 color = {1.0f, 1.0f, 1.0f, 1.0f};
    float age = 0.0f;
    bool attached = false;
};

struct EffectEvent {
    std::string effectName;
    Transform transform{};
    Vector4 color = {1.0f, 1.0f, 1.0f, 1.0f};
};

struct EffectRenderItem {
    const EffectAsset* asset = nullptr;
    const EffectComponentAsset* component = nullptr;
    const EffectInstance* instance = nullptr;
    const EffectComponentInstance* componentInstance = nullptr;
    EffectComponentType type = EffectComponentType::Particle;
    uint32_t renderQueue = 0;
    float normalizedAge = 0.0f;
};

class EffectSystem {
public:
    void RegisterAsset(EffectAsset asset);
    const EffectAsset* FindAsset(std::string_view name) const;

    uint32_t PlayEffect(std::string_view name, const Vector3& position);
    uint32_t PlayEffectWithParams(
        std::string_view name,
        const Vector3& position,
        const Vector4& color,
        const Vector3& scale);
    void StopEffect(uint32_t id);
    void Update(float deltaTime);
    void ClearInstances();
    EffectInstance* FindInstance(uint32_t id);
    void RestartInstance(uint32_t id);
    std::vector<EffectRenderItem> BuildRenderQueue(EffectLayer layer) const;
    std::vector<EffectRenderItem> BuildRenderQueue(EffectComponentType type) const;
    const EffectAsset* FindPrimaryAsset(EffectLayer layer) const;
    const EffectComponentAsset* FindPrimaryComponent(EffectComponentType type) const;

    const std::vector<EffectInstance>& Instances() const { return instances_; }
    std::vector<EffectInstance>& MutableInstances() { return instances_; }
    const std::unordered_map<std::string, EffectAsset>& Assets() const { return assets_; }

private:
    static void EnsureDefaultComponent(EffectAsset& asset);
    static const EffectComponentAsset* FindComponent(const EffectAsset& asset, uint32_t componentId);

    uint32_t nextInstanceId_ = 1;
    std::unordered_map<std::string, EffectAsset> assets_;
    std::vector<EffectInstance> instances_;
};
