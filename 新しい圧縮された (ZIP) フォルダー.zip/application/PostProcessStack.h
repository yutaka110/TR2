#pragma once

#include <string>
#include <vector>

struct PostProcessPass {
    std::string name;
    bool enabled = true;
    float intensity = 1.0f;
};

class PostProcessStack {
public:
    void ResetToVfxDefaults();
    void SetEnabled(const std::string& name, bool enabled);
    void SetIntensity(const std::string& name, float intensity);
    bool IsEnabled(const std::string& name) const;
    float Intensity(const std::string& name) const;
    const std::vector<PostProcessPass>& Passes() const { return passes_; }
    std::vector<PostProcessPass>& MutablePasses() { return passes_; }

private:
    std::vector<PostProcessPass> passes_;
};
