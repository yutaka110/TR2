#include "graphics/RenderGraph.h"

#include <algorithm>
#include <set>
#include <sstream>
#include <unordered_set>
#include <utility>

namespace ge3::graphics {

namespace {
int LayerOrder(RenderPassLayer layer) {
    switch (layer) {
    case RenderPassLayer::Geometry: return 0;
    case RenderPassLayer::Lighting: return 1;
    case RenderPassLayer::Vfx: return 2;
    case RenderPassLayer::PostProcess: return 3;
    case RenderPassLayer::Ui: return 4;
    case RenderPassLayer::Debug: return 5;
    }
    return 0;
}
} // namespace

void RenderGraph::Clear() {
    passes_.clear();
}

void RenderGraph::AddPass(RenderPassDesc pass) {
    passes_.push_back(std::move(pass));
}

std::vector<const RenderPassDesc*> RenderGraph::BuildExecutionList() const {
    std::vector<const RenderPassDesc*> orderedPasses;
    orderedPasses.reserve(passes_.size());
    for (const RenderPassDesc& pass : passes_) {
        orderedPasses.push_back(&pass);
    }

    std::stable_sort(
        orderedPasses.begin(),
        orderedPasses.end(),
        [](const RenderPassDesc* lhs, const RenderPassDesc* rhs) {
            return LayerOrder(lhs->layer) < LayerOrder(rhs->layer);
        });

    if (!passCullingEnabled_) {
        return orderedPasses;
    }

    std::unordered_set<std::string> needed;
    needed.insert(backBufferResource_);

    std::vector<const RenderPassDesc*> culled;
    for (auto it = orderedPasses.rbegin(); it != orderedPasses.rend(); ++it) {
        const RenderPassDesc* pass = *it;
        bool required = pass->forceExecute;
        for (const std::string& write : pass->writes) {
            if (needed.contains(write)) {
                required = true;
                break;
            }
        }

        if (!required) {
            continue;
        }

        for (const std::string& read : pass->reads) {
            needed.insert(read);
        }
        culled.push_back(pass);
    }

    std::reverse(culled.begin(), culled.end());
    return culled;
}

void RenderGraph::Execute(ID3D12GraphicsCommandList* commandList) const {
    if (commandList == nullptr) {
        return;
    }

    const std::vector<const RenderPassDesc*> orderedPasses = BuildExecutionList();
    RenderPassContext context{};
    context.commandList = commandList;
    for (const RenderPassDesc* pass : orderedPasses) {
        if (pass != nullptr && pass->execute) {
            pass->execute(context);
        }
    }
}

std::string RenderGraph::Describe() const {
    std::ostringstream stream;
    const std::vector<const RenderPassDesc*> executionList = BuildExecutionList();
    for (const RenderPassDesc* pass : executionList) {
        stream << ToString(pass->layer) << "." << pass->name;
        if (!pass->reads.empty()) {
            stream << " reads(";
            for (size_t i = 0; i < pass->reads.size(); ++i) {
                if (i != 0) {
                    stream << ", ";
                }
                stream << pass->reads[i];
            }
            stream << ")";
        }
        if (!pass->writes.empty()) {
            stream << " writes(";
            for (size_t i = 0; i < pass->writes.size(); ++i) {
                if (i != 0) {
                    stream << ", ";
                }
                stream << pass->writes[i];
            }
            stream << ")";
        }
        stream << "\n";
    }
    return stream.str();
}

bool RenderGraph::Validate(std::string* error) const {
    std::set<std::string> produced;
    for (const RenderPassDesc& pass : passes_) {
        for (const std::string& read : pass.reads) {
            if (read.empty()) {
                continue;
            }
            if (!produced.contains(read) && read != "SceneDepth" && read != "ParticleState") {
                if (error != nullptr) {
                    *error = "RenderGraph pass '" + pass.name + "' reads resource before it is produced: " + read;
                }
                return false;
            }
        }

        for (const std::string& write : pass.writes) {
            if (!write.empty()) {
                produced.insert(write);
            }
        }
    }
    return true;
}

void RenderGraph::SetBackBufferResource(std::string_view name) {
    backBufferResource_ = std::string(name);
}

const char* ToString(RenderPassLayer layer) {
    switch (layer) {
    case RenderPassLayer::Geometry: return "Geometry";
    case RenderPassLayer::Lighting: return "Lighting";
    case RenderPassLayer::Vfx: return "VFX";
    case RenderPassLayer::PostProcess: return "PostProcess";
    case RenderPassLayer::Ui: return "UI";
    case RenderPassLayer::Debug: return "Debug";
    }
    return "Unknown";
}

} // namespace ge3::graphics
