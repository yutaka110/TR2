#include "AppRunLoop.h"

#include "../../externals/imgui/imgui.h"
#include <DirectXMath.h>

#include "AppFrameRenderer.h"
#include "AppImGuiLayer.h"
#include "AppParticleSystem.h"
#include "AppPipelines.h"
#include "AppRenderResources.h"
#include "AppRuntimeState.h"
#include "AppSceneResources.h"
#include "EngineContext.h"

#include <filesystem>
#include <utility>

using namespace DirectX;
using namespace Microsoft::WRL;

AppRunLoop::AppRunLoop(
    DebugCamera& debugCamera,
    AppRuntimeState& runtimeState,
    AppSceneResources& scene,
    AppParticleSystem& particleSystem,
    AppImGuiLayer& imguiLayer,
    AppFrameRenderer& frameRenderer,
    AppPipelines& appPipelines,
    AppRenderResources& renderResources,
    graphics::SwapChain& swapChain,
    core::CommandListPool& clPool,
    EngineContext& engineContext,
    ge3::core::DescriptorHeapSet& heaps,
    core::Device& dev,
    ComPtr<ID3D12DescriptorHeap> srvDescriptorHeap,
    Matrix4x4* wvpData,
    uint32_t windowWidth,
    uint32_t windowHeight,
    FrameLoopState& frameState,
    ID3D12CommandQueue* commandQueue,
    ID3D12Fence* fence,
    HANDLE fenceEvent)
    : debugCamera_(debugCamera),
      runtimeState_(runtimeState),
      scene_(scene),
      particleSystem_(particleSystem),
      imguiLayer_(imguiLayer),
      frameRenderer_(frameRenderer),
      appPipelines_(appPipelines),
      renderResources_(renderResources),
      swapChain_(swapChain),
      clPool_(clPool),
      engineContext_(engineContext),
      heaps_(heaps),
      dev_(dev),
      srvDescriptorHeap_(srvDescriptorHeap),
      wvpData_(wvpData),
      windowWidth_(windowWidth),
      windowHeight_(windowHeight),
      frameState_(frameState),
      commandQueue_(commandQueue),
      fence_(fence),
      fenceEvent_(fenceEvent) {
    postProcessStack_.ResetToVfxDefaults();

    EffectAsset additiveParticle{};
    additiveParticle.name = "particle_additive";
    additiveParticle.shader = "Particle";
    additiveParticle.texture = "default";
    additiveParticle.passState.blend = ge3::graphics::BlendMode::Additive;
    additiveParticle.passState.depth = ge3::graphics::DepthMode::ReadOnly;
    additiveParticle.layer = EffectLayer::AdditiveFx;
    additiveParticle.lifetime = 2.0f;
    additiveParticle.emissive = 1.5f;
    effectSystem_.RegisterAsset(std::move(additiveParticle));

    loadedEffectAssets_ = effectAssetLoader_.LoadDirectory("Resources/effects");
    for (const LoadedEffectAsset& loaded : loadedEffectAssets_) {
        effectSystem_.RegisterAsset(loaded.asset);
    }
}

void AppRunLoop::InitializeBeam(
    ID3D12Device* device,
    ID3D12DescriptorHeap* srvDescriptorHeap,
    uint32_t descriptorSizeSRV,
    DXGI_FORMAT rtvFormat,
    DXGI_FORMAT dsvFormat) {
    beam_.Initialize(
        device,
        srvDescriptorHeap,
        descriptorSizeSRV,
        scene_.textureSrvHandleCPU,
        scene_.textureSrvHandleCPU2,
        rtvFormat,
        dsvFormat);
}

void AppRunLoop::Shutdown() {
    beam_.Shutdown();
}

void AppRunLoop::UpdateFrame() {
    appPipelines_.HotReloadIfNeeded(dev_.GetDevice());
    debugCamera_.Update();
    runtimeState_.cameraWorldPosition = debugCamera_.translation_;
    scene_.UpdateCameraWorldPosition(runtimeState_.cameraWorldPosition);
    frameState_.viewMatrix = debugCamera_.GetViewMatrix();
    frameState_.projMatrix = debugCamera_.GetProjectionMatrix();

    beamTime_ += 0.016f;
    beam_.SetTime(beamTime_);
    effectSystem_.Update(0.016f);

    for (LoadedEffectAsset& loaded : loadedEffectAssets_) {
        if (!std::filesystem::exists(loaded.path)) {
            continue;
        }

        const std::filesystem::file_time_type lastWriteTime =
            std::filesystem::last_write_time(loaded.path);
        if (lastWriteTime == loaded.lastWriteTime) {
            continue;
        }

        LoadedEffectAsset reloaded{};
        if (effectAssetLoader_.LoadFile(loaded.path, reloaded)) {
            effectSystem_.RegisterAsset(reloaded.asset);
            loaded = std::move(reloaded);
        }
    }

    BYTE key[256] = {};
    (void)key;

    frameState_.viewProjectionMatrix = Multiply(frameState_.viewMatrix, frameState_.projMatrix);
    frameState_.deltaTime += 0.016f;
    frameState_.drawCount = particleSystem_.UpdateInstances(
        frameState_.viewProjectionMatrix,
        frameState_.deltaTime);
}

void AppRunLoop::RenderFrame() {
    imguiLayer_.BeginFrame();
    frameTransientAllocator_.BeginFrame();
    resourceRegistry_.Clear();
    effectResourceCache_.BeginFrame();
    renderGraph_.Clear();

    UINT backBufferIndex = swapChain_.CurrentIndex();
    ComPtr<ID3D12GraphicsCommandList> commandList =
        clPool_.Begin(backBufferIndex, appPipelines_.GetMainPSO());
    gpuParticleSystem_.Initialize(
        dev_.GetDevice(),
        commandList.Get(),
        heaps_);
    vfxRenderTargets_.Initialize(
        dev_.GetDevice(),
        heaps_,
        windowWidth_,
        windowHeight_);

    ID3D12Resource* backBuffer = swapChain_.BackBuffer(backBufferIndex);
    auto dsvHandle = heaps_.dsv.GetHandle(engineContext_.GetMainDsvIndex()).cpu;
    D3D12_CPU_DESCRIPTOR_HANDLE rtv = swapChain_.RTV(backBufferIndex);
    resourceRegistry_.RegisterRenderTarget({
        "BackBuffer",
        {},
        rtv,
        {},
        DXGI_FORMAT_R8G8B8A8_UNORM,
        windowWidth_,
        windowHeight_
    });
    vfxRenderTargets_.Register(resourceRegistry_);
    effectResourceCache_.RegisterTexture({"default", scene_.textureSrvHandleCPU, scene_.textureSrvHandleGPU, 1, 1});
    effectResourceCache_.RegisterTexture({"monsterBall", scene_.textureSrvHandleCPU2, scene_.textureSrvHandleGPU2, 1, 1});
    effectResourceCache_.RegisterTexture({"streakNoise", scene_.textureSrvHandleCPU, scene_.textureSrvHandleGPU, 1, 1});

    frameRenderer_.BeginFrame(
        commandList.Get(),
        backBuffer,
        rtv,
        dsvHandle,
        runtimeState_.clearColor);
    vfxRenderTargets_.BeginScene(commandList.Get(), dsvHandle);

    UpdateFrame();

    scene_.UpdateTransforms(
        runtimeState_,
        wvpData_,
        frameState_.viewMatrix,
        frameState_.projMatrix,
        windowWidth_,
        windowHeight_);

    imguiLayer_.BuildUi(runtimeState_, effectSystem_, postProcessStack_, [&]() {
        Emitter emitterState{};
        emitterState.transform = runtimeState_.emitter.transform;
        emitterState.count = runtimeState_.emitter.count;
        emitterState.frequency = runtimeState_.emitter.frequency;
        emitterState.frequencyTime = runtimeState_.emitter.frequencyTime;
        particleSystem_.Emit(emitterState);
    });
    imguiLayer_.EndFrame();

    scene_.SyncRuntimeState(runtimeState_, frameState_.deltaTime);
    particleSystem_.SetAccelerationField({
        runtimeState_.accelerationField.acceleration,
        {runtimeState_.accelerationField.area.min, runtimeState_.accelerationField.area.max}
    });

    const D3D12_GPU_DESCRIPTOR_HANDLE spriteTextureHandle =
        runtimeState_.useMonsterBall ? scene_.textureSrvHandleGPU2 : scene_.textureSrvHandleGPU;
    const std::vector<EffectRenderItem> particleQueue =
        effectSystem_.BuildRenderQueue(EffectComponentType::Particle);
    const std::vector<EffectRenderItem> trailQueue =
        effectSystem_.BuildRenderQueue(EffectComponentType::Trail);
    const std::vector<EffectRenderItem> beamQueue =
        effectSystem_.BuildRenderQueue(EffectComponentType::Beam);
    const std::vector<EffectRenderItem> distortionQueue =
        effectSystem_.BuildRenderQueue(EffectComponentType::Distortion);
    const EffectComponentAsset* primaryParticleFx =
        !particleQueue.empty() ? particleQueue.front().component
                               : effectSystem_.FindPrimaryComponent(EffectComponentType::Particle);
    const D3D12_GPU_DESCRIPTOR_HANDLE vfxTextureHandle =
        primaryParticleFx != nullptr
            ? effectResourceCache_.ResolveTexture(primaryParticleFx->texture, spriteTextureHandle)
            : spriteTextureHandle;

    renderGraph_.AddPass({
        "Geometry.Sprite",
        ge3::graphics::RenderPassLayer::Geometry,
        {},
        {"SceneColor"},
        [&](ge3::graphics::RenderPassContext& context) {
            const bool spritePassReady = frameRenderer_.PrepareMainPass(
                context.commandList,
                runtimeState_.viewport,
                runtimeState_.scissorRect,
                appPipelines_.GetSpriteRootSignature(),
                appPipelines_.GetSpritePSO());

            if (spritePassReady &&
                scene_.materialResourceSprite &&
                scene_.transformationMatrixResourceSprite) {
                frameRenderer_.DrawSprite(
                    context.commandList,
                    srvDescriptorHeap_.Get(),
                    scene_.indexBufferViewSprite,
                    scene_.vertexBufferViewSprite,
                    scene_.materialResourceSprite->GetGPUVirtualAddress(),
                    scene_.transformationMatrixResourceSprite->GetGPUVirtualAddress(),
                    spriteTextureHandle);
            } else {
                OutputDebugStringA("[AppRunLoop] Sprite pass skipped because pipeline or resources are not ready.\n");
            }
        }});

    renderGraph_.AddPass({
        "Geometry.MainModel",
        ge3::graphics::RenderPassLayer::Geometry,
        {},
        {"SceneColor", "SceneDepth"},
        [&](ge3::graphics::RenderPassContext& context) {
            frameRenderer_.PrepareMainPass(
                context.commandList,
                runtimeState_.viewport,
                runtimeState_.scissorRect,
                appPipelines_.GetMainRootSignature(),
                appPipelines_.GetMainPSO());

            frameRenderer_.DrawMainModel(
                context.commandList,
                scene_.modelVBV,
                scene_.materialResource->GetGPUVirtualAddress(),
                scene_.sphere.cbvResource->GetGPUVirtualAddress(),
                scene_.textureSrvHandleGPU2,
                scene_.textureSrvHandleGPU2,
                scene_.textureSrvHandleGPU2,
                scene_.directionalLightResource->GetGPUVirtualAddress(),
                scene_.cameraResource->GetGPUVirtualAddress(),
                scene_.pointLightResource->GetGPUVirtualAddress(),
                scene_.spotLightResource->GetGPUVirtualAddress(),
                scene_.modelVertexCount);
        }});

    renderGraph_.AddPass({
        "VFX.ParticleSimulation",
        ge3::graphics::RenderPassLayer::Vfx,
        {"ParticleState"},
        {"ParticleState", "ParticleRenderBuffer"},
        [&](ge3::graphics::RenderPassContext& context) {
            ID3D12DescriptorHeap* descriptorHeaps[] = { srvDescriptorHeap_.Get() };
            context.commandList->SetDescriptorHeaps(1, descriptorHeaps);
            Vector4 tint = {1.0f, 1.0f, 1.0f, 1.0f};
            Vector3 scale = {1.0f, 1.0f, 1.0f};
            float emissive = 1.0f;
            float turbulence = 0.0f;
            float pulseSpeed = 5.0f;
            float spawnRadius = 4.0f;
            float uvScrollSpeed = 0.0f;
            if (!particleQueue.empty() && particleQueue.front().instance != nullptr &&
                particleQueue.front().component != nullptr) {
                const EffectRenderItem& item = particleQueue.front();
                tint = {
                    item.instance->color.x * item.component->color.x,
                    item.instance->color.y * item.component->color.y,
                    item.instance->color.z * item.component->color.z,
                    item.instance->color.w * item.component->color.w,
                };
                scale = item.instance->transform.scale;
                emissive = item.component->emissive;
                turbulence = item.component->noiseStrength + item.component->distortionStrength;
                pulseSpeed = item.component->pulseSpeed;
                spawnRadius = item.component->spawnRadius;
                uvScrollSpeed = item.component->uvScrollSpeed;
            } else if (primaryParticleFx != nullptr) {
                tint = primaryParticleFx->color;
                scale = primaryParticleFx->size;
                emissive = primaryParticleFx->emissive;
                turbulence = primaryParticleFx->noiseStrength + primaryParticleFx->distortionStrength;
                pulseSpeed = primaryParticleFx->pulseSpeed;
                spawnRadius = primaryParticleFx->spawnRadius;
                uvScrollSpeed = primaryParticleFx->uvScrollSpeed;
            }
            gpuParticleSystem_.Simulate(
                context.commandList,
                appPipelines_.GetGpuParticleComputeRootSignature(),
                appPipelines_.GetGpuParticleComputePSO(),
                frameState_.viewProjectionMatrix,
                0.016f,
                beamTime_,
                tint,
                scale,
                emissive,
                turbulence,
                pulseSpeed,
                spawnRadius,
                uvScrollSpeed);
        }});

    renderGraph_.AddPass({
        "VFX.BeginAccumulation",
        ge3::graphics::RenderPassLayer::Vfx,
        {"SceneDepth"},
        {"VfxAccumulation"},
        [&](ge3::graphics::RenderPassContext& context) {
            vfxRenderTargets_.BeginVfx(context.commandList, dsvHandle);
        }});

    renderGraph_.AddPass({
        "VFX.Particles",
        ge3::graphics::RenderPassLayer::Vfx,
        {"SceneColor", "SceneDepth"},
        {"VfxAccumulation"},
        [&](ge3::graphics::RenderPassContext& context) {
            if (!runtimeState_.enableParticles && particleQueue.empty()) {
                return;
            }

            frameRenderer_.DrawParticleComponents(
                context.commandList,
                appPipelines_.GetParticleRootSignature(),
                appPipelines_.GetParticleAlphaPSO(),
                gpuParticleSystem_.ParticleSrvGpuHandle(),
                renderResources_.ParticleVertexBufferView(),
                scene_.indexBufferViewSprite,
                vfxTextureHandle,
                gpuParticleSystem_.CommandSignature(),
                gpuParticleSystem_.IndirectArgsBuffer());
        }});

    renderGraph_.AddPass({
        "VFX.Trails",
        ge3::graphics::RenderPassLayer::Vfx,
        {"SceneColor", "SceneDepth"},
        {"VfxAccumulation"},
        [&](ge3::graphics::RenderPassContext& context) {
            if (trailQueue.empty()) {
                return;
            }

            frameRenderer_.DrawTrailComponents(
                context.commandList,
                appPipelines_.GetParticleRootSignature(),
                appPipelines_.GetTrailMeshPSO(),
                gpuParticleSystem_.ParticleSrvGpuHandle(),
                renderResources_.ParticleVertexBufferView(),
                scene_.indexBufferViewSprite,
                vfxTextureHandle,
                gpuParticleSystem_.CommandSignature(),
                gpuParticleSystem_.IndirectArgsBuffer());
        }});

    renderGraph_.AddPass({
        "VFX.Beam",
        ge3::graphics::RenderPassLayer::Vfx,
        {"SceneColor", "SceneDepth"},
        {"VfxAccumulation"},
        [&](ge3::graphics::RenderPassContext& context) {
            if (beamQueue.empty()) {
                return;
            }

            const EffectRenderItem& item = beamQueue.front();
            const EffectComponentAsset* component = item.component;
            const EffectInstance* instance = item.instance;
            if (component == nullptr || instance == nullptr) {
                return;
            }

            ID3D12DescriptorHeap* descriptorHeaps[] = { srvDescriptorHeap_.Get() };
            context.commandList->SetDescriptorHeaps(1, descriptorHeaps);
            XMMATRIX world = XMMatrixScaling(
                instance->transform.scale.x * component->size.x,
                instance->transform.scale.y * component->size.y,
                instance->transform.scale.z * component->size.z);
            world = XMMatrixMultiply(world, XMMatrixTranslation(
                instance->transform.translate.x,
                instance->transform.translate.y,
                instance->transform.translate.z));
            XMMATRIX view = XMMatrixSet(
                frameState_.viewMatrix.m[0][0], frameState_.viewMatrix.m[0][1], frameState_.viewMatrix.m[0][2], frameState_.viewMatrix.m[0][3],
                frameState_.viewMatrix.m[1][0], frameState_.viewMatrix.m[1][1], frameState_.viewMatrix.m[1][2], frameState_.viewMatrix.m[1][3],
                frameState_.viewMatrix.m[2][0], frameState_.viewMatrix.m[2][1], frameState_.viewMatrix.m[2][2], frameState_.viewMatrix.m[2][3],
                frameState_.viewMatrix.m[3][0], frameState_.viewMatrix.m[3][1], frameState_.viewMatrix.m[3][2], frameState_.viewMatrix.m[3][3]);
            XMMATRIX proj = XMMatrixSet(
                frameState_.projMatrix.m[0][0], frameState_.projMatrix.m[0][1], frameState_.projMatrix.m[0][2], frameState_.projMatrix.m[0][3],
                frameState_.projMatrix.m[1][0], frameState_.projMatrix.m[1][1], frameState_.projMatrix.m[1][2], frameState_.projMatrix.m[1][3],
                frameState_.projMatrix.m[2][0], frameState_.projMatrix.m[2][1], frameState_.projMatrix.m[2][2], frameState_.projMatrix.m[2][3],
                frameState_.projMatrix.m[3][0], frameState_.projMatrix.m[3][1], frameState_.projMatrix.m[3][2], frameState_.projMatrix.m[3][3]);
            XMMATRIX wvp = world * view * proj;
            XMFLOAT4 color = {
                instance->color.x * component->color.x,
                instance->color.y * component->color.y,
                instance->color.z * component->color.z,
                instance->color.w * component->color.w,
            };
            beam_.DrawTest(context.commandList, wvp, color, component->emissive);
        }});

    renderGraph_.AddPass({
        "VFX.Distortion",
        ge3::graphics::RenderPassLayer::Vfx,
        {"SceneColor", "SceneDepth"},
        {"VfxAccumulation"},
        [&](ge3::graphics::RenderPassContext& context) {
            if (distortionQueue.empty()) {
                return;
            }

            frameRenderer_.DrawDistortionComponents(
                context.commandList,
                appPipelines_.GetParticleRootSignature(),
                appPipelines_.GetDistortionSpritePSO(),
                gpuParticleSystem_.ParticleSrvGpuHandle(),
                renderResources_.ParticleVertexBufferView(),
                scene_.indexBufferViewSprite,
                vfxTextureHandle,
                gpuParticleSystem_.CommandSignature(),
                gpuParticleSystem_.IndirectArgsBuffer());
        }});

    for (const PostProcessPass& postPass : postProcessStack_.Passes()) {
        if (!postPass.enabled) {
            continue;
        }

        renderGraph_.AddPass({
            std::string("PostProcess.") + postPass.name,
            ge3::graphics::RenderPassLayer::PostProcess,
            {"SceneColor", "VfxAccumulation"},
            {"PostColor"},
            [postPass](ge3::graphics::RenderPassContext& context) {
                (void)context;
                (void)postPass;
        }});
    }

    renderGraph_.AddPass({
        "PostProcess.CompositeToBackBuffer",
        ge3::graphics::RenderPassLayer::PostProcess,
        {"SceneColor", "VfxAccumulation"},
        {"BackBuffer"},
        [&](ge3::graphics::RenderPassContext& context) {
            ID3D12DescriptorHeap* descriptorHeaps[] = { srvDescriptorHeap_.Get() };
            context.commandList->SetDescriptorHeaps(1, descriptorHeaps);
            const float compositeParams[4] = {
                postProcessStack_.Intensity("BloomExtract"),
                postProcessStack_.Intensity("DistortionComposite"),
                postProcessStack_.Intensity("GlowComposite"),
                postProcessStack_.Intensity("ToneMapping")
            };
            vfxRenderTargets_.CompositeToBackBuffer(
                context.commandList,
                backBuffer,
                rtv,
                appPipelines_.GetCompositeRootSignature(),
                appPipelines_.GetCompositePSO(),
                compositeParams);
            context.commandList->OMSetRenderTargets(1, &rtv, FALSE, &dsvHandle);
        }});

    {
        XMMATRIX world = XMMatrixScaling(2.0f, 4.0f, 1.0f);
        world = XMMatrixMultiply(world, XMMatrixTranslation(0.0f, 0.0f, 5.0f));
        XMMATRIX view = XMMatrixLookAtLH(
            XMVectorSet(0.f, 0.f, -5.f, 1.f),
            XMVectorSet(0.f, 0.f, 0.f, 1.f),
            XMVectorSet(0.f, 1.f, 0.f, 0.f));
        XMMATRIX proj = XMMatrixPerspectiveFovLH(
            XMConvertToRadians(60.0f),
            static_cast<float>(1280.0f) / static_cast<float>(720.0f),
            0.1f,
            100.0f);
        XMMATRIX wvp = world * view * proj;
        XMFLOAT4 color = {1.0f, 1.0f, 1.0f, 1.0f};
        float intensity = 1.0f;
        (void)wvp;
        (void)color;
        (void)intensity;
    }

    renderGraph_.AddPass({
        "UI.ImGui",
        ge3::graphics::RenderPassLayer::Ui,
        {"BackBuffer"},
        {"BackBuffer"},
        [&](ge3::graphics::RenderPassContext& context) {
            imguiLayer_.Render(context.commandList);
        }});

    std::string renderGraphError;
    if (!renderGraph_.Validate(&renderGraphError)) {
        OutputDebugStringA("[RenderGraph] ");
        OutputDebugStringA(renderGraphError.c_str());
        OutputDebugStringA("\n");
    }
    renderGraph_.Execute(commandList.Get());
    frameRenderer_.EndFrame(commandList.Get(), backBuffer);

    clPool_.EndAndExecute(dev_);
    swapChain_.Present(dev_, 1);

    uint64_t fenceValue = engineContext_.GetFenceValue() + 1;
    engineContext_.SetFenceValue(fenceValue);
    commandQueue_->Signal(fence_, fenceValue);
    if (fence_->GetCompletedValue() < fenceValue) {
        fence_->SetEventOnCompletion(fenceValue, fenceEvent_);
        WaitForSingleObject(fenceEvent_, INFINITE);
    }
}
