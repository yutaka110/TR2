#include "AppVfxRenderTargets.h"

namespace {
constexpr DXGI_FORMAT kVfxColorFormat = DXGI_FORMAT_R8G8B8A8_UNORM;

D3D12_RESOURCE_BARRIER MakeTransition(
    ID3D12Resource* resource,
    D3D12_RESOURCE_STATES before,
    D3D12_RESOURCE_STATES after) {
    D3D12_RESOURCE_BARRIER barrier{};
    barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barrier.Transition.pResource = resource;
    barrier.Transition.StateBefore = before;
    barrier.Transition.StateAfter = after;
    barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    return barrier;
}
} // namespace

bool AppVfxRenderTargets::Initialize(
    ID3D12Device* device,
    ge3::core::DescriptorHeapSet& heaps,
    uint32_t width,
    uint32_t height) {
    if (device == nullptr || width == 0 || height == 0) {
        return false;
    }

    if (initialized_ && width_ == width && height_ == height) {
        return true;
    }

    width_ = width;
    height_ = height;
    const float opaqueBlack[4] = {0.0f, 0.0f, 0.0f, 1.0f};
    const float transparentBlack[4] = {0.0f, 0.0f, 0.0f, 0.0f};
    initialized_ =
        CreateTarget(device, heaps, "SceneColor", width, height, opaqueBlack, sceneColor_) &&
        CreateTarget(device, heaps, "VfxAccumulation", width, height, transparentBlack, vfxAccumulation_) &&
        CreateTarget(device, heaps, "PostColor", width, height, transparentBlack, postColor_);
    return initialized_;
}

bool AppVfxRenderTargets::CreateTarget(
    ID3D12Device* device,
    ge3::core::DescriptorHeapSet& heaps,
    const char*,
    uint32_t width,
    uint32_t height,
    const float clearColor[4],
    Target& target) {
    D3D12_RESOURCE_DESC desc{};
    desc.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
    desc.Width = width;
    desc.Height = height;
    desc.DepthOrArraySize = 1;
    desc.MipLevels = 1;
    desc.Format = kVfxColorFormat;
    desc.SampleDesc.Count = 1;
    desc.Layout = D3D12_TEXTURE_LAYOUT_UNKNOWN;
    desc.Flags = D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET;

    D3D12_CLEAR_VALUE clearValue{};
    clearValue.Format = kVfxColorFormat;
    clearValue.Color[0] = clearColor[0];
    clearValue.Color[1] = clearColor[1];
    clearValue.Color[2] = clearColor[2];
    clearValue.Color[3] = clearColor[3];

    D3D12_HEAP_PROPERTIES heapProperties{};
    heapProperties.Type = D3D12_HEAP_TYPE_DEFAULT;

    HRESULT hr = device->CreateCommittedResource(
        &heapProperties,
        D3D12_HEAP_FLAG_NONE,
        &desc,
        D3D12_RESOURCE_STATE_RENDER_TARGET,
        &clearValue,
        IID_PPV_ARGS(&target.resource));
    if (FAILED(hr)) {
        return false;
    }

    target.rtv = heaps.rtv.Allocate();
    target.srv = heaps.srv.Allocate();
    target.state = D3D12_RESOURCE_STATE_RENDER_TARGET;

    D3D12_RENDER_TARGET_VIEW_DESC rtvDesc{};
    rtvDesc.Format = kVfxColorFormat;
    rtvDesc.ViewDimension = D3D12_RTV_DIMENSION_TEXTURE2D;
    device->CreateRenderTargetView(target.resource.Get(), &rtvDesc, target.rtv.cpu);

    D3D12_SHADER_RESOURCE_VIEW_DESC srvDesc{};
    srvDesc.Format = kVfxColorFormat;
    srvDesc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
    srvDesc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
    srvDesc.Texture2D.MipLevels = 1;
    device->CreateShaderResourceView(target.resource.Get(), &srvDesc, target.srv.cpu);
    return true;
}

void AppVfxRenderTargets::Register(ge3::resources::ResourceRegistry& registry) const {
    registry.RegisterRenderTarget({"SceneColor", sceneColor_.resource, sceneColor_.rtv.cpu, sceneColor_.srv.gpu, kVfxColorFormat, width_, height_});
    registry.RegisterRenderTarget({"VfxAccumulation", vfxAccumulation_.resource, vfxAccumulation_.rtv.cpu, vfxAccumulation_.srv.gpu, kVfxColorFormat, width_, height_});
    registry.RegisterRenderTarget({"PostColor", postColor_.resource, postColor_.rtv.cpu, postColor_.srv.gpu, kVfxColorFormat, width_, height_});
}

void AppVfxRenderTargets::Transition(
    ID3D12GraphicsCommandList* commandList,
    Target& target,
    D3D12_RESOURCE_STATES after) {
    if (commandList == nullptr || target.resource == nullptr || target.state == after) {
        return;
    }

    D3D12_RESOURCE_BARRIER barrier = MakeTransition(target.resource.Get(), target.state, after);
    commandList->ResourceBarrier(1, &barrier);
    target.state = after;
}

void AppVfxRenderTargets::BeginScene(
    ID3D12GraphicsCommandList* commandList,
    D3D12_CPU_DESCRIPTOR_HANDLE dsv) {
    if (!initialized_ || commandList == nullptr) {
        return;
    }

    Transition(commandList, sceneColor_, D3D12_RESOURCE_STATE_RENDER_TARGET);
    Transition(commandList, vfxAccumulation_, D3D12_RESOURCE_STATE_RENDER_TARGET);
    Transition(commandList, postColor_, D3D12_RESOURCE_STATE_RENDER_TARGET);

    const float clearScene[4] = {0.0f, 0.0f, 0.0f, 1.0f};
    const float clearVfx[4] = {0.0f, 0.0f, 0.0f, 0.0f};
    const float clearPost[4] = {0.0f, 0.0f, 0.0f, 0.0f};
    commandList->ClearRenderTargetView(sceneColor_.rtv.cpu, clearScene, 0, nullptr);
    commandList->ClearRenderTargetView(vfxAccumulation_.rtv.cpu, clearVfx, 0, nullptr);
    commandList->ClearRenderTargetView(postColor_.rtv.cpu, clearPost, 0, nullptr);
    commandList->OMSetRenderTargets(1, &sceneColor_.rtv.cpu, FALSE, &dsv);
}

void AppVfxRenderTargets::BeginVfx(
    ID3D12GraphicsCommandList* commandList,
    D3D12_CPU_DESCRIPTOR_HANDLE dsv) {
    if (!initialized_ || commandList == nullptr) {
        return;
    }

    Transition(commandList, vfxAccumulation_, D3D12_RESOURCE_STATE_RENDER_TARGET);
    commandList->OMSetRenderTargets(1, &vfxAccumulation_.rtv.cpu, FALSE, &dsv);
}

void AppVfxRenderTargets::CompositeToBackBuffer(
    ID3D12GraphicsCommandList* commandList,
    ID3D12Resource* backBuffer,
    D3D12_CPU_DESCRIPTOR_HANDLE backBufferRtv,
    ID3D12RootSignature* rootSignature,
    ID3D12PipelineState* pipelineState,
    const float compositeParams[4]) {
    if (!initialized_ || commandList == nullptr || backBuffer == nullptr ||
        rootSignature == nullptr || pipelineState == nullptr) {
        return;
    }

    Transition(commandList, sceneColor_, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);
    Transition(commandList, vfxAccumulation_, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);
    Transition(commandList, postColor_, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE);

    (void)backBuffer;
    commandList->OMSetRenderTargets(1, &backBufferRtv, FALSE, nullptr);
    commandList->SetGraphicsRootSignature(rootSignature);
    commandList->SetPipelineState(pipelineState);
    commandList->SetGraphicsRootDescriptorTable(0, sceneColor_.srv.gpu);
    commandList->SetGraphicsRootDescriptorTable(1, vfxAccumulation_.srv.gpu);
    commandList->SetGraphicsRootDescriptorTable(2, postColor_.srv.gpu);
    commandList->SetGraphicsRoot32BitConstants(3, 4, compositeParams, 0);
    commandList->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    commandList->DrawInstanced(3, 1, 0, 0);
}
