Texture2D gTrailTex : register(t0);
SamplerState gSampler : register(s0);

struct PSIn
{
    float4 position : SV_POSITION;
    float2 texcoord : TEXCOORD;
    float4 color : COLOR0;
};

float4 main(PSIn input) : SV_TARGET
{
    float4 tex = gTrailTex.Sample(gSampler, input.texcoord);
    float center = 1.0f - abs(input.texcoord.x - 0.5f) * 2.0f;
    float tail = pow(saturate(1.0f - input.texcoord.y), 1.35f);
    float alpha = tex.a * input.color.a * smoothstep(0.0f, 0.65f, center) * tail;

    float3 color = tex.rgb * input.color.rgb * alpha * 2.2f;
    return float4(color, alpha);
}
