#include "EffectAssetLoader.h"

#include <algorithm>
#include <cctype>
#include <fstream>
#include <sstream>

namespace {
std::string Trim(std::string text) {
    const auto first = std::find_if_not(text.begin(), text.end(), [](unsigned char ch) {
        return std::isspace(ch) != 0;
    });
    const auto last = std::find_if_not(text.rbegin(), text.rend(), [](unsigned char ch) {
        return std::isspace(ch) != 0;
    }).base();
    if (first >= last) {
        return {};
    }
    return std::string(first, last);
}

float ToFloat(const std::string& value, float fallback) {
    try {
        return std::stof(value);
    } catch (...) {
        return fallback;
    }
}

ge3::graphics::BlendMode ParseBlend(const std::string& value) {
    if (value == "alpha") {
        return ge3::graphics::BlendMode::Alpha;
    }
    if (value == "additive") {
        return ge3::graphics::BlendMode::Additive;
    }
    if (value == "distortion") {
        return ge3::graphics::BlendMode::Distortion;
    }
    return ge3::graphics::BlendMode::Opaque;
}

EffectLayer ParseLayer(const std::string& value) {
    if (value == "opaque") {
        return EffectLayer::OpaqueFx;
    }
    if (value == "distortion") {
        return EffectLayer::DistortionFx;
    }
    if (value == "trail") {
        return EffectLayer::TrailFx;
    }
    if (value == "volumetric") {
        return EffectLayer::VolumetricFx;
    }
    return EffectLayer::AdditiveFx;
}

EffectComponentType ParseComponentType(const std::string& value) {
    if (value == "trail") {
        return EffectComponentType::Trail;
    }
    if (value == "beam") {
        return EffectComponentType::Beam;
    }
    if (value == "distortion") {
        return EffectComponentType::Distortion;
    }
    return EffectComponentType::Particle;
}

EffectComponentAsset MakeComponentFromAsset(
    const EffectAsset& asset,
    EffectComponentType type,
    uint32_t id) {
    EffectComponentAsset component{};
    component.id = id;
    component.type = type;
    component.name = asset.name + "_component_" + std::to_string(id);
    component.shader = asset.shader;
    component.texture = asset.texture;
    component.passState = asset.passState;
    component.layer = asset.layer;
    component.startTime = 0.0f;
    component.duration = asset.lifetime;
    component.emissive = asset.emissive;
    component.distortionStrength = asset.distortionStrength;
    component.noiseStrength = asset.noiseStrength;
    component.uvScrollSpeed = asset.uvScrollSpeed;
    component.pulseSpeed = asset.pulseSpeed;
    component.spawnRadius = asset.spawnRadius;
    component.color = asset.color;
    component.size = asset.size;

    if (type == EffectComponentType::Trail) {
        component.layer = EffectLayer::TrailFx;
        component.passState.renderQueue += 100;
    } else if (type == EffectComponentType::Beam) {
        component.layer = EffectLayer::AdditiveFx;
        component.passState.renderQueue += 200;
    } else if (type == EffectComponentType::Distortion) {
        component.layer = EffectLayer::DistortionFx;
        component.passState.blend = ge3::graphics::BlendMode::Distortion;
        component.passState.renderQueue += 300;
    }
    return component;
}
} // namespace

std::vector<LoadedEffectAsset> EffectAssetLoader::LoadDirectory(
    const std::filesystem::path& directory) const {
    std::vector<LoadedEffectAsset> assets;
    if (!std::filesystem::exists(directory)) {
        return assets;
    }

    for (const std::filesystem::directory_entry& entry : std::filesystem::directory_iterator(directory)) {
        if (!entry.is_regular_file() || entry.path().extension() != ".effect") {
            continue;
        }

        LoadedEffectAsset loaded{};
        if (LoadFile(entry.path(), loaded)) {
            assets.push_back(std::move(loaded));
        }
    }
    return assets;
}

bool EffectAssetLoader::LoadFile(const std::filesystem::path& path, LoadedEffectAsset& outAsset) const {
    std::ifstream file(path);
    if (!file.is_open()) {
        return false;
    }

    EffectAsset asset{};
    asset.name = path.stem().string();
    asset.passState.blend = ge3::graphics::BlendMode::Additive;
    asset.passState.depth = ge3::graphics::DepthMode::ReadOnly;
    EffectComponentAsset* currentComponent = nullptr;
    uint32_t nextComponentId = 1;

    std::string line;
    while (std::getline(file, line)) {
        const size_t comment = line.find('#');
        if (comment != std::string::npos) {
            line = line.substr(0, comment);
        }

        const size_t separator = line.find('=');
        if (separator == std::string::npos) {
            continue;
        }

        const std::string key = Trim(line.substr(0, separator));
        const std::string value = Trim(line.substr(separator + 1));
        if (key == "component") {
            asset.components.push_back(MakeComponentFromAsset(
                asset,
                ParseComponentType(value),
                nextComponentId++));
            currentComponent = &asset.components.back();
            continue;
        }

        if (currentComponent != nullptr) {
            ApplyComponentKeyValue(*currentComponent, key, value);
        } else {
            ApplyKeyValue(asset, key, value);
        }
    }

    outAsset.asset = std::move(asset);
    outAsset.path = path;
    outAsset.lastWriteTime = std::filesystem::last_write_time(path);
    return true;
}

bool EffectAssetLoader::ApplyKeyValue(
    EffectAsset& asset,
    const std::string& key,
    const std::string& value) {
    if (key == "name") {
        asset.name = value;
    } else if (key == "shader") {
        asset.shader = value;
    } else if (key == "texture") {
        asset.texture = value;
    } else if (key == "blend") {
        asset.passState.blend = ParseBlend(value);
    } else if (key == "layer") {
        asset.layer = ParseLayer(value);
    } else if (key == "lifetime") {
        asset.lifetime = ToFloat(value, asset.lifetime);
    } else if (key == "emissive") {
        asset.emissive = ToFloat(value, asset.emissive);
    } else if (key == "distortion") {
        asset.distortionStrength = ToFloat(value, asset.distortionStrength);
    } else if (key == "noise") {
        asset.noiseStrength = ToFloat(value, asset.noiseStrength);
    } else if (key == "uvScroll") {
        asset.uvScrollSpeed = ToFloat(value, asset.uvScrollSpeed);
    } else if (key == "pulseSpeed") {
        asset.pulseSpeed = ToFloat(value, asset.pulseSpeed);
    } else if (key == "spawnRadius") {
        asset.spawnRadius = ToFloat(value, asset.spawnRadius);
    } else if (key == "renderQueue") {
        asset.passState.renderQueue = static_cast<uint32_t>(ToFloat(value, static_cast<float>(asset.passState.renderQueue)));
    } else if (key == "size") {
        std::stringstream stream(value);
        char comma = ',';
        float x = asset.size.x;
        float y = asset.size.y;
        float z = asset.size.z;
        if (stream >> x) {
            if (stream >> comma >> y >> comma >> z) {
                asset.size = {x, y, z};
            } else {
                asset.size = {x, x, x};
            }
        }
    } else if (key == "color") {
        std::stringstream stream(value);
        char comma = ',';
        stream >> asset.color.x >> comma >> asset.color.y >> comma >> asset.color.z;
        if (stream >> comma >> asset.color.w) {
        }
    } else {
        return false;
    }
    return true;
}

bool EffectAssetLoader::ApplyComponentKeyValue(
    EffectComponentAsset& component,
    const std::string& key,
    const std::string& value) {
    if (key == "name") {
        component.name = value;
    } else if (key == "shader") {
        component.shader = value;
    } else if (key == "texture") {
        component.texture = value;
    } else if (key == "blend") {
        component.passState.blend = ParseBlend(value);
    } else if (key == "layer") {
        component.layer = ParseLayer(value);
    } else if (key == "start" || key == "startTime") {
        component.startTime = ToFloat(value, component.startTime);
    } else if (key == "duration" || key == "lifetime") {
        component.duration = ToFloat(value, component.duration);
    } else if (key == "emissive") {
        component.emissive = ToFloat(value, component.emissive);
    } else if (key == "distortion") {
        component.distortionStrength = ToFloat(value, component.distortionStrength);
    } else if (key == "noise") {
        component.noiseStrength = ToFloat(value, component.noiseStrength);
    } else if (key == "uvScroll") {
        component.uvScrollSpeed = ToFloat(value, component.uvScrollSpeed);
    } else if (key == "pulseSpeed") {
        component.pulseSpeed = ToFloat(value, component.pulseSpeed);
    } else if (key == "spawnRadius") {
        component.spawnRadius = ToFloat(value, component.spawnRadius);
    } else if (key == "renderQueue") {
        component.passState.renderQueue = static_cast<uint32_t>(
            ToFloat(value, static_cast<float>(component.passState.renderQueue)));
    } else if (key == "size") {
        std::stringstream stream(value);
        char comma = ',';
        float x = component.size.x;
        float y = component.size.y;
        float z = component.size.z;
        if (stream >> x) {
            if (stream >> comma >> y >> comma >> z) {
                component.size = {x, y, z};
            } else {
                component.size = {x, x, x};
            }
        }
    } else if (key == "color") {
        std::stringstream stream(value);
        char comma = ',';
        stream >> component.color.x >> comma >> component.color.y >> comma >> component.color.z;
        if (stream >> comma >> component.color.w) {
        }
    } else {
        return false;
    }
    return true;
}
