#pragma once

#include <functional>
#include <string_view>
#include <string>
#include <vector>

#include <d3d12.h>

namespace ge3::graphics {

enum class RenderPassLayer {
    Geometry,
    Lighting,
    Vfx,
    PostProcess,
    Ui,
    Debug,
};

struct RenderPassContext {
    ID3D12GraphicsCommandList* commandList = nullptr;
};

struct RenderPassDesc {
    std::string name;
    RenderPassLayer layer = RenderPassLayer::Geometry;
    std::vector<std::string> reads;
    std::vector<std::string> writes;
    std::function<void(RenderPassContext&)> execute;
    bool forceExecute = false;
};

class RenderGraph {
public:
    void Clear();
    void AddPass(RenderPassDesc pass);
    void Execute(ID3D12GraphicsCommandList* commandList) const;
    std::string Describe() const;
    bool Validate(std::string* error) const;
    void SetBackBufferResource(std::string_view name);
    void SetPassCullingEnabled(bool enabled) { passCullingEnabled_ = enabled; }

    const std::vector<RenderPassDesc>& Passes() const { return passes_; }
    bool Empty() const { return passes_.empty(); }

private:
    std::vector<const RenderPassDesc*> BuildExecutionList() const;

    std::vector<RenderPassDesc> passes_;
    std::string backBufferResource_ = "BackBuffer";
    bool passCullingEnabled_ = true;
};

const char* ToString(RenderPassLayer layer);

} // namespace ge3::graphics
